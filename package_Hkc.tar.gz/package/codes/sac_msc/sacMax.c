/********************************************************
*	Show SAC data max. amplitude withing specified time window
*	Usage:
*		sacMax [-Wt1/t2] sac_files ...
********************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "sac.h"

int main(int argc, char **argv) {
  SACHEAD	hd;
  char		temp[128];
  int		j,n,n1,n2,deviation,error,win;
  float		*ar;
  float		t1, t2, am, t, sigma, dev;

  deviation = 0;
  error = 0;
  win = 0;
  for (j=1; !error && j < argc; j++) {
     if (argv[j][0] == '-') {
        switch(argv[j][1]) {
	case 'W':
	    win = 1;
            sscanf(&argv[j][2], "%f/%f",&t1,&t2);
	    break;
	case 'D':
	    deviation = 1;
	    break;
	default:
	    error = 1;
	}
     }
  }
  if (argc == 1 || error) {
     fprintf(stderr, "show location of max. amp. in a SAC trace\n\
	Usage: sacMax [-D -Wt1/t2] sac_files ...\n\
		-W  specify time window\n\
		-D  output standard deviation using stacked deviation in .std\n\
	Output: name tm dev Am\n");
     return -1;
  }

  while(*(++argv)) {
     if (argv[0][0] == '-' || (ar = read_sac(*argv,&hd)) == NULL) continue;
     n1 = 0; n2 = hd.npts-1;
     if (win) {
        n1 = rint((t1-hd.b)/hd.delta);if(n1<0) n1=0;
        n2 = rint((t2-hd.b)/hd.delta);if(n2>hd.npts-1) n2=hd.npts-1;
     }
     if (n1>n2) {
        fprintf(stderr,"no time window for %s, %d %d\n",*argv,n1,n2);
	continue;
     }
     for(am=ar[n1],n=n1,j=n1+1;j<n2;j++) {
	if (n==n1 && am>ar[j]) am=ar[j];
        if (ar[j]>am && ar[j]>=ar[j-1] && ar[j]>ar[j+1]) {
           am = ar[j];
           n = j;
	}
     }
     if (n==n1) {
        fprintf(stderr,"%s Warning: no max. found\n",*argv);
     } else {
     sigma = 1./(2*ar[n]-ar[n-1]-ar[n+1]);
     t = 0.5*(ar[n+1]-ar[n-1])*sigma;
     am = am + 0.5*t*t/sigma;
     free(ar);
     dev = 1.;
     if (deviation) {
	strcpy(temp,*argv);
	strcat(temp,".std");
        if ((ar = read_sac(temp,&hd)) != NULL) {dev = ar[n]; free(ar);}
     }
     printf("%s %9.5f %9.5f %8.2e\n", *argv,(n+t)*hd.delta+hd.b,sqrt(2*dev*sigma)*hd.delta,am);
     }
  }

  return 0;
}
