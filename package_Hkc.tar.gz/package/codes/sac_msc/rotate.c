/*********************************************************************
*	rotate.c:
*		grid-search for best-orientations of horizontal
*		components to maximize radial energy
*
*	Author:  Lupei Zhu
*
*	Revision History
*		Jan. 1999	Initial coding based on T.J. Owens's
*********************************************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sac.h"

int main(int argc, char **argv) {
  int 		i, j, k, sl, n, k1, k2, clockwise;
  char		tttt[128];
  float 	max,re1,re2,az,daz,best_az,*r,*t;
  float		caz, saz, pi=3.1415926, tw=0.3;
  SACHEAD	hdr, hdt;

  if (argc < 2) {
    fprintf(stderr,"usage: %s filename.r ...\n",argv[0]);
    return -1;
  }

  n = 360;
  daz = 2*pi/n;
  for (j=1; j<argc; j++,free(r),free(t)) {

    strcpy(tttt,argv[j]);
    fprintf(stderr,"%s\n",tttt);

    if ( (r=read_sac(tttt, &hdr)) == NULL ) continue;
    sl=strlen(tttt)-3;
    tttt[sl] = 't';
    if ( (t=read_sac(tttt, &hdt)) == NULL ) continue;
    k1 = rint((-tw-hdr.b)/hdr.delta);
    k2 = rint((tw-hdr.b)/hdr.delta)+1;
    if (k1<0 || k2>hdr.npts) {
       fprintf(stderr," no p pulse\n");
       continue;
    }

    max = -1;
    for (az=0,i=0; i<n; i++,az+=daz) {
      caz = cos(az);
      saz = sin(az);
      for(re1=0.,re2=0.,k=k1; k<k2; k++) {
        re1 += r[k]*caz + t[k]*saz;
        re2 += r[k]*caz - t[k]*saz;
      }
      k=1;
      if (re2>re1) {
	re1 = re2;
	k=0;
      }
      if (re1 > max) {
	best_az = az;
	clockwise = k;
	max = re1;
      }
    }

    if (max<0.) {
      fprintf(stderr," no best-orientation is found\n");
      continue;
    }

    /* rotate and save */
    caz = cos(best_az);
    saz = sin(best_az);
    best_az = best_az*180/pi;
    hdr.cmpaz += best_az;
    hdt.cmpaz += best_az;
    hdt.user3 = clockwise;
    if (!clockwise) saz = -saz;
    for(k=0;k<hdr.npts;k++) {
      re1 = r[k]*caz + t[k]*saz;
      re2 = t[k]*caz - r[k]*saz;
      r[k] = re1;
      t[k] = re2;
    }
    write_sac(tttt, hdt, t);
    tttt[sl] = 'r';
    write_sac(tttt, hdr, r);

  }

  return 0;

}
