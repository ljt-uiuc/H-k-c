/*********************************************************************
*	rotate.c:
*		grid-search for best-orientations of horizontal
*		components to maximize radial energy
*
*	Author:  Lupei Zhu
*
*	Revision History
*		Jan. 1999	Initial coding based on T.J. Owens's
*********************************************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sac.h"

int main(int argc, char **argv) {
  int 		i, j, k, sl, n, k1, k2, clockwise, error;
  char		tttt[128];
  float 	max,re1,re2,az1,az2,daz,best_az,*r,*t;
  float		caz, saz, pi1, tBefore;
  SACHEAD	hdr, hdt;

  pi1 = 3.1415926/180.;
  error = 0;
  mark = -2;
  tBefore = 0;
  n = 10;
  az1 = 0;
  az2 = 360;
  daz = 1;
  /* input parameters */
  for (i=1; !error && i < argc; i++) {
    if (argv[i][0] == '-') {
       switch(argv[i][1]) {
       case 'A':
         sscanf(&argv[i][2],"%f/%f/%f",&az1,&az2,&daz);
         az1 *= pi1; az2 *= pi1; daz *= pi1;
         break;
       case 'W':
         sscanf(&argv[i][2],"%d/%f/%d",&mark,&tBefore,&n);
         break;
    } else {
       error  = 1;
    }
  }
  if (argc == 1 || error ) {
    fprintf(stderr,"usage: [-Aaz1/az2/daz] [-Wmark/tBefore/n] sacFiles ...\n\
    -A: input azimuth range and interval in degrees (0/360/1)\n\
    -W: time window. mark=0-9,-2(a),-3(o),-5(b). (-2/0/10)\n",argv[0]);
    return -1;
  }

  while (argv) {
    if (argv[0][0] == '-') {argv++;continue;}
    fprintf(stderr,"%s\n",*argv);
    r=read_sac(*argv, &hdr); argv++;
    t=read_sac(*argv, &hdt); argv++;
    if (r==NULL || t==NULL ) continue;
    k1 = rint((tBefore-hdr.b)/hdr.delta);
    k2 = k1+n;
    if (k1<0 || k2>hdr.npts || k2>hdt.npts) {
       fprintf(stderr," no p pulse\n");
       free(r);free(t);
       continue;
    }

    max = FLT_MAX;
    for (az=az1,i=0; az<az2; i++,az+=daz) {
      caz = cos(az);
      saz = sin(az);
      for(re1=0.,re2=0.,k=k1; k<k2; k++) {
        re1 += r[k]*caz + t[k]*saz;
        re2 += r[k]*caz - t[k]*saz;
      }
      k=1;
      if (re2>re1) {
	re1 = re2;
	k=0;
      }
      if (re1 > max) {
	best_az = az;
	clockwise = k;
	max = re1;
      }
    }

    if (max<0.) {
      fprintf(stderr," no best-orientation is found\n");
      continue;
    }

  }

  return 0;

}
