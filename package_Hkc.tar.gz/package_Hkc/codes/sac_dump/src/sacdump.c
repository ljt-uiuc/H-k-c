/***************************************************************************
 * sacdump.c
 *
 * Read and dump details from SAC files.
 * No support is included for SAC spectral or generic X-Y data.
 *
 * Written by Chad Trabant, IRIS Data Management Center
 *
 * modified 2011.131
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>
#include <math.h>

#include <libmseed.h>

#include "sacformat.h"

#define VERSION "1.0"
#define PACKAGE "sacdump"

#if defined (LWP_WIN32)
  #define strtoull _strtoui64
#endif

struct listnode {
  char *key;
  char *data;
  struct listnode *next;
};

static int printallheaders (struct SACHeader *sh);
static int printheaders (struct SACHeader *sh);

static int printstats (float *fdata, int count);
static int parsesac (FILE *ifp, struct SACHeader *sh, float **data, int format,
		     int verbose, char *sacfile);
static int readbinaryheader (FILE *ifp, struct SACHeader *sh, int *format,
			     int *swapflag, int verbose, char *sacfile);
static int readbinarydata (FILE *ifp, float *data, int datacnt,
			   int swapflag, int verbose, char *sacfile);
static int readalphaheader (FILE *ifp, struct SACHeader *sh);
static int readalphadata (FILE *ifp, float *data, int datacnt);
static int swapsacheader (struct SACHeader *sh);
static int writemetadata (struct SACHeader *sh, hptime_t starttime, int expanded);
static int parameter_proc (int argcount, char **argvec);
static char *getoptval (int argcount, char **argvec, int argopt);
static int readlistfile (char *listfile);
static void addnode (struct listnode **listroot, char *key, char *data);
static void usage (void);


static int   verbose     = 0;    /* Flag to control verbosity */
static int   sacformat   = 0;    /* Flag to specify SAC file format */
static int   expmeta     = 0;    /* Flag to control extended metadata output */
static int   allheaders  = 0;    /* Flag to control printing of all defined headers */
static int   bareflag    = 0;    /* Flag to control printing of file name */
static int   dataflag    = 0;    /* Flag to control data sample output */
static int   datastats   = 0;    /* Flag to control data statistics output */
static int   timeformat  = 0;    /* Time string format for data output */
static char *metafile    = 0;    /* File to write metadata to */
static FILE *mfp         = 0;    /* File pointer for metafile */

/* A list of input files */
struct listnode *filelist = 0;

/* A list of header fields */
struct listnode *headerlist = 0;

int
main (int argc, char **argv)
{
  FILE *ifp = 0;
  struct listnode *flp;
  struct SACHeader sh;
  hptime_t timeval;
  char timestr[50];
  float *fdata = 0;
  int datacnt;
  int idx;

  /* Process given parameters (command line and parameter file) */
  if (parameter_proc (argc, argv) < 0)
    return -1;
  
  /* Open the metadata output file if specified */
  if ( metafile )
    {
      if ( strcmp (metafile, "-") == 0 )
        {
          mfp = stdout;
        }
      else if ( (mfp = fopen (metafile, "wb")) == NULL )
        {
          fprintf (stderr, "Cannot open metadata output file: %s (%s)\n",
                   metafile, strerror(errno));
          return -1;
        }
    }
  
  /* Read input SAC files */
  flp = filelist;
  while ( flp != 0 )
    {
      if ( verbose )
	fprintf (stderr, "Reading %s\n", flp->data);

      /* Open input file */
      if ( (ifp = fopen (flp->data, "rb")) == NULL )
	{
	  fprintf (stderr, "Cannot open input file: %s (%s)\n",
		   flp->data, strerror(errno));
	  return -1;
	}

      if ( (datacnt = parsesac (ifp, &sh, &fdata, sacformat, verbose, flp->data)) < 0 )
	{
	  fprintf (stderr, "Error parsing %s\n", flp->data);
	  
	  return -1;
	}
      
      fclose (ifp);

      /* Print file name if not bare output */
      if ( ! bareflag )
	{
	  printf ("%s:\n", flp->data);
	}
      
      /* Convert SAC time fields to hptime_t */
      timeval = ms_time2hptime (sh.nzyear, sh.nzjday, sh.nzhour,
				sh.nzmin, sh.nzsec, sh.nzmsec * 1000);
      
      /* Adjust for Begin ('B' SAC variable) time offset */
      timeval += (hptime_t) ((double) sh.b * HPTMODULUS);
      
      /* Write metadata to file if requested */
      if ( mfp )
	{
	  if ( verbose )
	    fprintf (stderr, "[%s] Writing metadata to %s\n", flp->data, metafile);
	  
	  if ( writemetadata (&sh, timeval, expmeta) )
	    {
	      fprintf (stderr, "Error writing metadata to file '%s'\n", metafile);
	      
	      return -1;
	    }
	}
      
      /* Print list of defined header values */
      if ( allheaders )
	{
	  if ( printallheaders (&sh) )
	    {
	      fprintf (stderr, "[%s] Error printing header values\n", flp->data);
	      
	      return -1;
	    }
	}
      
      /* Print specified header values */
      if ( headerlist )
	{
	  if ( printheaders (&sh) )
	    {
	      fprintf (stderr, "[%s] Error printing header values\n", flp->data);
	      
	      return -1;
	    }
	}

      /* Print sample statstistics */
      if ( datastats )
	{
	  if ( printstats (fdata, sh.npts) )
	    {
	      fprintf (stderr, "[%s] Error printing data statistics\n", flp->data);
	      
	      return -1;
	    }
	}
      
      /* Print data samples */
      if ( dataflag )
	{
	  int cnt = ( dataflag == 1 ) ? 20 : sh.npts;
	  hptime_t period = (hptime_t) ((double) sh.delta * HPTMODULUS);

	  /* Print data header if not bare output */
	  if ( ! bareflag )
	    {
	      printf ("Data samples:\n");
	    }
	  
	  for (idx = 0; idx < cnt; idx++ )
	    {
	      switch ( timeformat )
		{
		case 0:
		  ms_hptime2seedtimestr (timeval, timestr, 1); break;
		case 1:
		  ms_hptime2isotimestr (timeval, timestr, 1); break;
		case 2:
		  snprintf (timestr, sizeof(timestr), "%.6f", (double)MS_HPTIME2EPOCH(timeval)); break;
		}
	      
	      printf ("%s  %g\n", timestr, fdata[idx]);
	      
	      /* Add sampling interval to time value */
	      timeval += period;
	    }
	}
      
      if ( fdata )
	free (fdata);
      
      flp = flp->next;
    }
  
  /* Make sure everything is cleaned up */
  
  if ( mfp )
    fclose (mfp);
  
  return 0;
}  /* End of main() */


/***************************************************************************
 * printallheaders:
 *
 * Print all defined header variables from the given header structure.
 *
 * Returns 0 on sucess and -1 on failure.
 ***************************************************************************/
static int
printallheaders (struct SACHeader *sh)
{

  /* Float headers */
  if ( sh->delta != FUNDEF ) printf ("%9s = %g\n", "DELTA", sh->delta);
  if ( sh->depmin != FUNDEF ) printf ("%9s = %g\n", "DEPMIN", sh->depmin);
  if ( sh->depmax != FUNDEF ) printf ("%9s = %g\n", "DEPMAX", sh->depmax);
  if ( sh->scale != FUNDEF ) printf ("%9s = %g\n", "SCALE", sh->scale);
  if ( sh->odelta != FUNDEF ) printf ("%9s = %g\n", "ODELTA", sh->odelta);
  if ( sh->b != FUNDEF ) printf ("%9s = %g\n", "B", sh->b);
  if ( sh->e != FUNDEF ) printf ("%9s = %g\n", "E", sh->e);
  if ( sh->o != FUNDEF ) printf ("%9s = %g\n", "O", sh->o);
  if ( sh->a != FUNDEF ) printf ("%9s = %g\n", "A", sh->a);
  if ( sh->t0 != FUNDEF ) printf ("%9s = %g\n", "T0", sh->t0);
  if ( sh->t1 != FUNDEF ) printf ("%9s = %g\n", "T1", sh->t1);
  if ( sh->t2 != FUNDEF ) printf ("%9s = %g\n", "T2", sh->t2);
  if ( sh->t3 != FUNDEF ) printf ("%9s = %g\n", "T3", sh->t3);
  if ( sh->t4 != FUNDEF ) printf ("%9s = %g\n", "T4", sh->t4);
  if ( sh->t5 != FUNDEF ) printf ("%9s = %g\n", "T5", sh->t5);
  if ( sh->t6 != FUNDEF ) printf ("%9s = %g\n", "T6", sh->t6);
  if ( sh->t7 != FUNDEF ) printf ("%9s = %g\n", "T7", sh->t7);
  if ( sh->t8 != FUNDEF ) printf ("%9s = %g\n", "T8", sh->t8);
  if ( sh->t9 != FUNDEF ) printf ("%9s = %g\n", "T9", sh->t9);
  if ( sh->f != FUNDEF ) printf ("%9s = %g\n", "F", sh->f);
  if ( sh->stla != FUNDEF ) printf ("%9s = %g\n", "STLA", sh->stla);
  if ( sh->stlo != FUNDEF ) printf ("%9s = %g\n", "STLO", sh->stlo);
  if ( sh->stel != FUNDEF ) printf ("%9s = %g\n", "STEL", sh->stel);
  if ( sh->stdp != FUNDEF ) printf ("%9s = %g\n", "STDP", sh->stdp);
  if ( sh->evla != FUNDEF ) printf ("%9s = %g\n", "EVLA", sh->evla);
  if ( sh->evlo != FUNDEF ) printf ("%9s = %g\n", "EVLO", sh->evlo);
  if ( sh->evel != FUNDEF ) printf ("%9s = %g\n", "EVEL", sh->evel);
  if ( sh->evdp != FUNDEF ) printf ("%9s = %g\n", "EVDP", sh->evdp);
  if ( sh->mag != FUNDEF ) printf ("%9s = %g\n", "MAG", sh->mag);
  if ( sh->user0 != FUNDEF ) printf ("%9s = %g\n", "USER0", sh->user0);
  if ( sh->user1 != FUNDEF ) printf ("%9s = %g\n", "USER1", sh->user1);
  if ( sh->user2 != FUNDEF ) printf ("%9s = %g\n", "USER2", sh->user2);
  if ( sh->user3 != FUNDEF ) printf ("%9s = %g\n", "USER3", sh->user3);
  if ( sh->user4 != FUNDEF ) printf ("%9s = %g\n", "USER4", sh->user4);
  if ( sh->user5 != FUNDEF ) printf ("%9s = %g\n", "USER5", sh->user5);
  if ( sh->user6 != FUNDEF ) printf ("%9s = %g\n", "USER6", sh->user6);
  if ( sh->user7 != FUNDEF ) printf ("%9s = %g\n", "USER7", sh->user7);
  if ( sh->user8 != FUNDEF ) printf ("%9s = %g\n", "USER8", sh->user8);
  if ( sh->user9 != FUNDEF ) printf ("%9s = %g\n", "USER9", sh->user9);
  if ( sh->dist != FUNDEF ) printf ("%9s = %g\n", "DIST", sh->dist);
  if ( sh->az != FUNDEF ) printf ("%9s = %g\n", "AZ", sh->az);
  if ( sh->baz != FUNDEF ) printf ("%9s = %g\n", "BAZ", sh->baz);
  if ( sh->gcarc != FUNDEF ) printf ("%9s = %g\n", "GCARC", sh->gcarc);
  if ( sh->depmen != FUNDEF ) printf ("%9s = %g\n", "DEPMEN", sh->depmen);
  if ( sh->cmpaz != FUNDEF ) printf ("%9s = %g\n", "CMPAZ", sh->cmpaz);
  if ( sh->cmpinc != FUNDEF ) printf ("%9s = %g\n", "CMPINC", sh->cmpinc);
  
  /* Integer headers */
  if ( sh->nzyear != IUNDEF && sh->nzjday != IUNDEF )
    {
      int month, mday;
      char *monthstr[] = {"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
      
      ms_doy2md (sh->nzyear, sh->nzjday, &month, &mday);
      
      printf ("%9s = %s %02d (%03d), %04d\n", "KZDATE", monthstr[month-1], mday, sh->nzjday, sh->nzyear);
    }
  if ( sh->nzhour != IUNDEF && sh->nzmin != IUNDEF &&
       sh->nzsec != IUNDEF && sh->nzmsec != IUNDEF )
    {
      printf ("%9s = %02d:%02d:%02d.%03d\n", "KZTIME", sh->nzhour, sh->nzmin, sh->nzsec, sh->nzmsec);
    }
  if ( sh->nvhdr != IUNDEF ) printf ("%9s = %d\n", "NVHDR", sh->nvhdr);
  if ( sh->norid != IUNDEF ) printf ("%9s = %d\n", "NORID", sh->norid);
  if ( sh->nevid != IUNDEF ) printf ("%9s = %d\n", "NEVID", sh->nevid);
  if ( sh->npts != IUNDEF ) printf ("%9s = %d\n", "NPTS", sh->npts);
  if ( sh->nwfid != IUNDEF ) printf ("%9s = %d\n", "NWFID", sh->nwfid);
  if ( sh->iftype != IUNDEF ) printf ("%9s = %d\n", "IFTYPE", sh->iftype);
  if ( sh->idep != IUNDEF ) printf ("%9s = %d\n", "IDEP", sh->idep);
  if ( sh->iztype != IUNDEF ) printf ("%9s = %d\n", "IZTYPE", sh->iztype);
  if ( sh->istreg != IUNDEF ) printf ("%9s = %d\n", "ISTREG", sh->istreg);
  if ( sh->ievreg != IUNDEF ) printf ("%9s = %d\n", "IEVREG", sh->ievreg);
  if ( sh->ievtyp != IUNDEF ) printf ("%9s = %d\n", "IEVTYP", sh->ievtyp);
  if ( sh->iqual != IUNDEF ) printf ("%9s = %d\n", "IQUAL", sh->iqual);
  if ( sh->isynth != IUNDEF ) printf ("%9s = %d\n", "ISYNTH", sh->isynth);
  if ( sh->imagtyp != IUNDEF ) printf ("%9s = %d\n", "IMAGTYP", sh->imagtyp);
  if ( sh->imagsrc != IUNDEF ) printf ("%9s = %d\n", "IMAGSRC", sh->imagsrc);
  if ( sh->leven != IUNDEF ) printf ("%9s = %d\n", "LEVEN", sh->leven);
  if ( sh->lpspol != IUNDEF ) printf ("%9s = %d\n", "LPSPOL", sh->lpspol);
  if ( sh->lovrok != IUNDEF ) printf ("%9s = %d\n", "LOVROK", sh->lovrok);
  if ( sh->lcalda != IUNDEF ) printf ("%9s = %d\n", "LCALDA", sh->lcalda);

  /* String headers */
  if ( strncmp (sh->kstnm, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KSTNM", sh->kstnm);
  if ( strncmp (sh->kevnm, SUNDEF, 6) ) printf ("%9s = %.16s\n", "KEVNM", sh->kevnm);
  if ( strncmp (sh->khole, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KHOLE", sh->khole);
  if ( strncmp (sh->ko, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KO", sh->ko);
  if ( strncmp (sh->ka, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KA", sh->ka);
  if ( strncmp (sh->kt0, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT0", sh->kt0);
  if ( strncmp (sh->kt1, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT1", sh->kt1);
  if ( strncmp (sh->kt2, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT2", sh->kt2);
  if ( strncmp (sh->kt3, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT3", sh->kt3);
  if ( strncmp (sh->kt4, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT4", sh->kt4);
  if ( strncmp (sh->kt5, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT5", sh->kt5);
  if ( strncmp (sh->kt6, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT6", sh->kt6);
  if ( strncmp (sh->kt7, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT7", sh->kt7);
  if ( strncmp (sh->kt8, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT8", sh->kt8);
  if ( strncmp (sh->kt9, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KT9", sh->kt9);
  if ( strncmp (sh->kf, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KF", sh->kf);
  if ( strncmp (sh->kuser0, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KUSER0", sh->kuser0);
  if ( strncmp (sh->kuser1, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KUSER1", sh->kuser1);
  if ( strncmp (sh->kuser2, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KUSER2", sh->kuser2);
  if ( strncmp (sh->kcmpnm, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KCMPNM", sh->kcmpnm);
  if ( strncmp (sh->knetwk, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KNETWK", sh->knetwk);
  if ( strncmp (sh->kdatrd, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KDATRD", sh->kdatrd);
  if ( strncmp (sh->kinst, SUNDEF, 6) ) printf ("%9s = %.8s\n", "KINST", sh->kinst);
  
  return 0;
}  /* End of printallheaders() */


/***************************************************************************
 * printheaders:
 *
 * Print header variables from the given header structure.
 *
 * Returns 0 on sucess and -1 on failure.
 ***************************************************************************/
static int
printheaders (struct SACHeader *sh)
{
  struct listnode *hlp;
  
  hlp = headerlist;
  while ( hlp != 0 )
    {
      /* Float headers */
      if ( ! strcasecmp (hlp->data, "delta") ) {
	if ( sh->delta == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->delta); }
      else if ( ! strcasecmp (hlp->data, "depmin") ) {
	if ( sh->depmin == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->depmin); }
      else if ( ! strcasecmp (hlp->data, "depmax") ) {
	if ( sh->depmax == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->depmax); }
      else if ( ! strcasecmp (hlp->data, "scale") ) {
	if ( sh->scale == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->scale); }
      else if ( ! strcasecmp (hlp->data, "odelta") ) {
	if ( sh->odelta == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->odelta); }
      else if ( ! strcasecmp (hlp->data, "b") ) {
	if ( sh->b == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->b); }
      else if ( ! strcasecmp (hlp->data, "e") ) {
	if ( sh->e == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->e); }
      else if ( ! strcasecmp (hlp->data, "o") ) {
	if ( sh->o == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->o); }
      else if ( ! strcasecmp (hlp->data, "a") ) {
	if ( sh->a == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->a); }
      else if ( ! strcasecmp (hlp->data, "t0") ) {
	if ( sh->t0 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t0); }
      else if ( ! strcasecmp (hlp->data, "t1") ) {
	if ( sh->t1 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t1); }
      else if ( ! strcasecmp (hlp->data, "t2") ) {
	if ( sh->t2 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t2); }
      else if ( ! strcasecmp (hlp->data, "t3") ) {
	if ( sh->t3 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t3); }
      else if ( ! strcasecmp (hlp->data, "t4") ) {
	if ( sh->t4 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t4); }
      else if ( ! strcasecmp (hlp->data, "t5") ) {
	if ( sh->t5 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t5); }
      else if ( ! strcasecmp (hlp->data, "t6") ) {
	if ( sh->t6 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t6); }
      else if ( ! strcasecmp (hlp->data, "t7") ) {
	if ( sh->t7 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t7); }
      else if ( ! strcasecmp (hlp->data, "t8") ) {
	if ( sh->t8 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t8); }
      else if ( ! strcasecmp (hlp->data, "t9") ) {
	if ( sh->t9 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->t9); }
      else if ( ! strcasecmp (hlp->data, "f") ) {
	if ( sh->f == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->f); }
      else if ( ! strcasecmp (hlp->data, "stla") ) {
	if ( sh->stla == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->stla); }
      else if ( ! strcasecmp (hlp->data, "stlo") ) {
	if ( sh->stlo == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->stlo); }
      else if ( ! strcasecmp (hlp->data, "stel") ) {
	if ( sh->stel == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->stel); }
      else if ( ! strcasecmp (hlp->data, "stdp") ) {
	if ( sh->stdp == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->stdp); }
      else if ( ! strcasecmp (hlp->data, "evla") ) {
	if ( sh->evla == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->evla); }
      else if ( ! strcasecmp (hlp->data, "evlo") ) {
	if ( sh->evlo == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->evlo); }
      else if ( ! strcasecmp (hlp->data, "evel") ) {
	if ( sh->evel == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->evel); }
      else if ( ! strcasecmp (hlp->data, "evdp") ) {
	if ( sh->evdp == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->evdp); }
      else if ( ! strcasecmp (hlp->data, "mag") ) {
	if ( sh->mag == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->mag); }
      else if ( ! strcasecmp (hlp->data, "user0") ) {
	if ( sh->user0 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user0); }
      else if ( ! strcasecmp (hlp->data, "user1") ) {
	if ( sh->user1 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user1); }
      else if ( ! strcasecmp (hlp->data, "user2") ) {
	if ( sh->user2 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user2); }
      else if ( ! strcasecmp (hlp->data, "user3") ) {
	if ( sh->user3 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user3); }
      else if ( ! strcasecmp (hlp->data, "user4") ) {
	if ( sh->user4 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user4); }
      else if ( ! strcasecmp (hlp->data, "user5") ) {
	if ( sh->user5 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user5); }
      else if ( ! strcasecmp (hlp->data, "user6") ) {
	if ( sh->user6 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user6); }
      else if ( ! strcasecmp (hlp->data, "user7") ) {
	if ( sh->user7 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user7); }
      else if ( ! strcasecmp (hlp->data, "user8") ) {
	if ( sh->user8 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user8); }
      else if ( ! strcasecmp (hlp->data, "user9") ) {
	if ( sh->user9 == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->user9); }
      else if ( ! strcasecmp (hlp->data, "dist") ) {
	if ( sh->dist == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->dist); }
      else if ( ! strcasecmp (hlp->data, "az") ) {
	if ( sh->az == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->az); }
      else if ( ! strcasecmp (hlp->data, "baz") ) {
	if ( sh->baz == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->baz); }
      else if ( ! strcasecmp (hlp->data, "gcarc") ) {
	if ( sh->gcarc == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->gcarc); }
      else if ( ! strcasecmp (hlp->data, "depmen") ) {
	if ( sh->depmen == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->depmen); }
      else if ( ! strcasecmp (hlp->data, "cmpaz") ) {
	if ( sh->cmpaz == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->cmpaz); }
      else if ( ! strcasecmp (hlp->data, "cmpinc") ) {
	if ( sh->cmpinc == FUNDEF ) printf ("UNDEF  ");
	else printf ("%g  ", sh->cmpinc); }

      /* Integer headers */
      else if ( ! strcasecmp (hlp->data, "nzyear") ) {
	if ( sh->nzyear == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->nzyear); }
      else if ( ! strcasecmp (hlp->data, "nzjday") ) {
	if ( sh->nzjday == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->nzjday); }
      else if ( ! strcasecmp (hlp->data, "nzhour") ) {
	if ( sh->nzhour == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->nzhour); }
      else if ( ! strcasecmp (hlp->data, "nzmin") ) {
	if ( sh->nzmin == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->nzmin); }
      else if ( ! strcasecmp (hlp->data, "nzsec") ) {
	if ( sh->nzsec == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->nzsec); }
      else if ( ! strcasecmp (hlp->data, "nzmsec") ) {
	if ( sh->nzmsec == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->nzmsec); }
      else if ( ! strcasecmp (hlp->data, "nvhdr") ) {
	if ( sh->nvhdr == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->nvhdr); }
      else if ( ! strcasecmp (hlp->data, "norid") ) {
	if ( sh->norid == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->norid); }
      else if ( ! strcasecmp (hlp->data, "nevid") ) {
	if ( sh->nevid == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->nevid); }
      else if ( ! strcasecmp (hlp->data, "npts") ) {
	if ( sh->npts == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->npts); }
      else if ( ! strcasecmp (hlp->data, "nwfid") ) {
	if ( sh->nwfid == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->nwfid); }
      else if ( ! strcasecmp (hlp->data, "iftype") ) {
	if ( sh->iftype == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->iftype); }
      else if ( ! strcasecmp (hlp->data, "idep") ) {
	if ( sh->idep == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->idep); }
      else if ( ! strcasecmp (hlp->data, "iztype") ) {
	if ( sh->iztype == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->iztype); }
      else if ( ! strcasecmp (hlp->data, "istreg") ) {
	if ( sh->istreg == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->istreg); }
      else if ( ! strcasecmp (hlp->data, "ievreg") ) {
	if ( sh->ievreg == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->ievreg); }
      else if ( ! strcasecmp (hlp->data, "ievtyp") ) {
	if ( sh->ievtyp == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->ievtyp); }
      else if ( ! strcasecmp (hlp->data, "iqual") ) {
	if ( sh->iqual == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->iqual); }
      else if ( ! strcasecmp (hlp->data, "isynth") ) {
	if ( sh->isynth == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->isynth); }
      else if ( ! strcasecmp (hlp->data, "imagtyp") ) {
	if ( sh->imagtyp == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->imagtyp); }
      else if ( ! strcasecmp (hlp->data, "imagsrc") ) {
	if ( sh->imagsrc == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->imagsrc); }
      else if ( ! strcasecmp (hlp->data, "leven") ) {
	if ( sh->leven == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->leven); }
      else if ( ! strcasecmp (hlp->data, "lpspol") ) {
	if ( sh->lpspol == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->lpspol); }
      else if ( ! strcasecmp (hlp->data, "lovrok") ) {
	if ( sh->lovrok == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->lovrok); }
      else if ( ! strcasecmp (hlp->data, "lcalda") ) {
	if ( sh->lcalda == IUNDEF ) printf ("UNDEF  ");
	else printf ("%d  ", sh->lcalda); }

      /* String headers */
      else if ( ! strcasecmp (hlp->data, "kstnm") ) {
	if ( ! strncmp (sh->kstnm, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kstnm); }
      else if ( ! strcasecmp (hlp->data, "kevnm") ) {
	if ( ! strncmp (sh->kevnm, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.16s  ", sh->kevnm); }
      else if ( ! strcasecmp (hlp->data, "khole") ) {
	if ( ! strncmp (sh->khole, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->khole); }
      else if ( ! strcasecmp (hlp->data, "ko") ) {
	if ( ! strncmp (sh->ko, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->ko); }
      else if ( ! strcasecmp (hlp->data, "ka") ) {
	if ( ! strncmp (sh->ka, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->ka); }
      else if ( ! strcasecmp (hlp->data, "kt0") ) {
	if ( ! strncmp (sh->kt0, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt0); }
      else if ( ! strcasecmp (hlp->data, "kt1") ) {
	if ( ! strncmp (sh->kt1, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt1); }
      else if ( ! strcasecmp (hlp->data, "kt2") ) {
	if ( ! strncmp (sh->kt2, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt2); }
      else if ( ! strcasecmp (hlp->data, "kt3") ) {
	if ( ! strncmp (sh->kt3, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt3); }
      else if ( ! strcasecmp (hlp->data, "kt4") ) {
	if ( ! strncmp (sh->kt4, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt4); }
      else if ( ! strcasecmp (hlp->data, "kt5") ) {
	if ( ! strncmp (sh->kt5, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt5); }
      else if ( ! strcasecmp (hlp->data, "kt6") ) {
	if ( ! strncmp (sh->kt6, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt6); }
      else if ( ! strcasecmp (hlp->data, "kt7") ) {
	if ( ! strncmp (sh->kt7, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt7); }
      else if ( ! strcasecmp (hlp->data, "kt8") ) {
	if ( ! strncmp (sh->kt8, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt8); }
      else if ( ! strcasecmp (hlp->data, "kt9") ) {
	if ( ! strncmp (sh->kt9, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kt9); }
      else if ( ! strcasecmp (hlp->data, "kf") ) {
	if ( ! strncmp (sh->kf, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kf); }
      else if ( ! strcasecmp (hlp->data, "kuser0") ) {
	if ( ! strncmp (sh->kuser0, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kuser0); }
      else if ( ! strcasecmp (hlp->data, "kuser1") ) {
	if ( ! strncmp (sh->kuser1, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kuser1); }
      else if ( ! strcasecmp (hlp->data, "kuser2") ) {
	if ( ! strncmp (sh->kuser2, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kuser2); }
      else if ( ! strcasecmp (hlp->data, "kcmpnm") ) {
	if ( ! strncmp (sh->kcmpnm, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kcmpnm); }
      else if ( ! strcasecmp (hlp->data, "knetwk") ) {
	if ( ! strncmp (sh->knetwk, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->knetwk); }
      else if ( ! strcasecmp (hlp->data, "kdatrd") ) {
	if ( ! strncmp (sh->kdatrd, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kdatrd); }
      else if ( ! strcasecmp (hlp->data, "kinst") ) {
	if ( ! strncmp (sh->kinst, SUNDEF, 6) ) printf ("UNDEF  ");
	else printf ("%.8s  ", sh->kinst); }

      /* Virtual headers */
      else if ( ! strcasecmp (hlp->data, "kzdate") ) {
	if ( sh->nzyear == IUNDEF || sh->nzjday == IUNDEF ) printf ("UNDEF  ");
	else {
	  int month, mday;
	  char *monthstr[] = {"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
	  
	  ms_doy2md (sh->nzyear, sh->nzjday, &month, &mday);
	  
	  printf ("%s %02d (%03d), %04d  ", monthstr[month-1], mday, sh->nzjday, sh->nzyear);
	}
      }
      else if ( ! strcasecmp (hlp->data, "kztime") ) {
	if ( sh->nzhour == IUNDEF || sh->nzmin == IUNDEF ||
	     sh->nzsec == IUNDEF || sh->nzmsec == IUNDEF ) printf ("UNDEF  ");
	else {
	  printf ("%02d:%02d:%02d.%03d  ", sh->nzhour, sh->nzmin, sh->nzsec, sh->nzmsec);
	}
      }
      
      else
	fprintf (stderr, "Unrecognized header variable name: '%s'\n", hlp->data);
      
      hlp = hlp->next;
    }

  printf ("\n");
  
  return 0;
}  /* End of printheaders() */


/***************************************************************************
 * printstats:
 *
 * Calculate and print basic sample value stats.
 *
 * Running arithmetic mean and standard deviation calculations are
 * based on Knuth's "The Art of Computer Programming: Semi-Numerical
 * Algorithms" who further credits B.P. Welford, "Technometrics 4"
 * (1962), 419-420.
 *
 * The algorithm goes:
 * M[1] = x[1];  S[1] = 0;
 * for (i=2; i<=n; ++i) {
 *   M[i] = M[i-1] + (x[i] - M[i-1]) / i
 *   S[i] = S[i-1] + (x[i] - M[i-1]) * (x[i] - M[i])
 * }
 * SD = sqrt(S[n] / (n -1)); 
 *
 * RMS (root-mean-square) is related to the standard deviation (SD)
 * and the arithmetic mean (M) in the following way:
 * 
 * RMS^2 = M^2 + SD^2
 *  or
 * RMS = sqrt( M^2 + SD^2 )
 *
 * Returns 0 on sucess and -1 on failure.
 ***************************************************************************/
static int
printstats (float *fdata, int count)
{
  int idx;

  double min;
  double max;
  double mean;
  double SD;
  double RMS;

  double pM, M;
  double pS, S;
  
  if ( ! fdata )
    return -1;

  /* Initialize */
  min = *fdata;
  max = *fdata;
  mean = *fdata;
  pM = M = mean;
  pS = S = 0.0;
  
  for ( idx = 1; idx < count; idx++ )
    {
      /* Check for max and min sample values */
      if ( *(fdata+idx) > max )
        max = *(fdata+idx);
      
      if ( *(fdata+idx) < min )
        min = *(fdata+idx);
      
      /* Update the mean and variance deviation "accumulator" */
      M = pM + (*(fdata+idx) - pM) / (idx + 1);
      S = pS + (*(fdata+idx) - pM) * (*(fdata+idx) - M);
      
      pM = M;
      pS = S;
    }
  
  if ( S < 0.0 )
    {
      fprintf (stderr, "Accumulator overload, S: %g sample: %g\n", S, *(fdata+idx));
      return -1;
    }

  mean = M;
  SD = sqrt( S / (count - 1) );
  RMS = sqrt( (mean * mean) + (SD * SD) );

  /* Print statistics */
  printf ("Min: %g, Max: %g, Mean: %g, SD: %g, RMS: %g\n",
	  min, max, mean, SD, RMS);
  
  return 0;
} /* End of printstats */


/***************************************************************************
 * parsesac:
 *
 * Parse a SAC file, autodetecting format dialect (ALPHA,
 * binary, big or little endian).  Results will be placed in the
 * supplied SAC header struct and data (float sample array in host
 * byte order).  The data array will be allocated by this routine and
 * must be free'd by the caller.  The data array will contain the
 * number of samples indicated in the SAC header (sh->npts).
 *
 * The format argument is interpreted as:
 * 0 : Unknown, detection needed
 * 1 : ALPHA
 * 2 : Binary, byte order detection needed
 * 3 : Binary, little endian
 * 4 : Binary, big endian
 *
 * Returns number of data samples in file or -1 on failure.
 ***************************************************************************/
static int
parsesac (FILE *ifp, struct SACHeader *sh, float **data, int format,
	  int verbose, char *sacfile)
{
  char fourc[4];
  int swapflag = 0;
  int rv;
  
  /* Argument sanity */
  if ( ! ifp || ! sh || ! data )
    return -1;
  
  /* Read the first 4 characters */
  if ( fread (&fourc, 4, 1, ifp) < 1 )
    return -1;
  
  /* Determine if the file is ALPHA or binary SAC,
   * if the first 4 characters are spaces assume ALPHA SAC */
  if ( format == 0 )
    {
      if ( fourc[0] == ' ' && fourc[1] == ' ' && fourc[2] == ' ' && fourc[3] == ' ' )
	format = 1;
      else
	format = 2;  /* Byte order detection will occur below */
    }
  
  /* Rewind the file position pointer to the beginning */
  rewind (ifp);
  
  /* Read the header */
  if ( format == 1 )  /* Process SAC ALPHA header */
    {
      if ( (rv = readalphaheader (ifp, sh)) )
	{
	  fprintf (stderr, "[%s] Error parsing SAC ALPHA header at line %d\n",
		   sacfile, rv);
	  return -1;
	}
    }
  else if ( format >= 2 && format <= 4 ) /* Process SAC binary header */
    {
      if ( readbinaryheader (ifp, sh, &format, &swapflag, verbose, sacfile) )
	{
	  fprintf (stderr, "[%s] Error parsing SAC header\n", sacfile);
	  return -1;
	}
    }
  else
    {
      fprintf (stderr, "[%s] Unrecognized format value: %d\n", sacfile, format);
      return -1;
    }
  
  /* Fix up underspecified year values by adding 1900 */
  if ( sh->nzyear >= 0 && sh->nzyear <= 200 )
    {
      if ( verbose )
        fprintf (stderr, "[%s] Adding 1900 to underspecified year value (%d)\n", sacfile, sh->nzyear);

      sh->nzyear += 1900;
    }
  
  /* Sanity check the start time */
  if ( sh->nzyear < 1900 || sh->nzyear > 3000 ||
       sh->nzjday < 1 || sh->nzjday > 366 ||
       sh->nzhour < 0 || sh->nzhour > 23 ||
       sh->nzmin < 0 || sh->nzmin > 59 ||
       sh->nzsec < 0 || sh->nzsec > 60 ||
       sh->nzmsec < 0 || sh->nzmsec > 999999 )
    {
      fprintf (stderr, "[%s] Unrecognized format (not SAC?)\n", sacfile);
      return -1;
    }
  
  if ( verbose )
    {
      if ( format == 1 )
	fprintf (stderr, "[%s] Reading SAC ALPHA format\n", sacfile);
      if ( format == 3 )
	fprintf (stderr, "[%s] Reading SAC binary format (little-endian)\n", sacfile);
      if ( format == 4 )
	fprintf (stderr, "[%s] Reading SAC binary format (big-endian)\n", sacfile);
    }
  
  if ( verbose > 2 )
    fprintf (stderr, "[%s] SAC header version number: %d\n", sacfile, sh->nvhdr);
  
  if ( sh->nvhdr != 6 )
    fprintf (stderr, "[%s] WARNING SAC header version (%d) not expected value of 6\n",
	     sacfile, sh->nvhdr);
  
  if ( sh->npts <= 0 )
    {
      fprintf (stderr, "[%s] No data, number of samples: %d\n", sacfile, sh->npts);
      return -1;
    }
  
  if ( sh->iftype != ITIME )
    {
      fprintf (stderr, "[%s] Data is not time series (IFTYPE=%d), cannot convert other types\n",
	       sacfile, sh->iftype);
      return -1;
    }
  
  if ( ! sh->leven )
    {
      fprintf (stderr, "[%s] Data is not evenly spaced (LEVEN not true), cannot convert\n", sacfile);
      return -1;
    }
  

  /* Allocate space for data samples */
  *data = (float *) malloc (sizeof(float) * sh->npts);
  memset (*data, 0, (sizeof(float) * sh->npts));
  
  /* Read the data samples */
  if ( format == 1 )  /* Process SAC ALPHA data */
    {
      if ( (rv = readalphadata (ifp, *data, sh->npts)) )
	{
	  fprintf (stderr, "[%s] Error parsing SAC ALPHA data at line %d\n",
		   sacfile, rv);
	  return -1;
	}
    }
  else if ( format >= 2 && format <= 4 ) /* Process SAC binary data */
    {
      if ( readbinarydata (ifp, *data, sh->npts, swapflag, verbose, sacfile) )
	{
	  fprintf (stderr, "[%s] Error reading SAC data samples\n", sacfile);
	  return -1;
	}
    }
  else
    {
      fprintf (stderr, "[%s] Unrecognized format value: %d\n", sacfile, format);
      return -1;
    }      
  
  return sh->npts;
}  /* End of parsesac() */


/***************************************************************************
 * readbinaryheader:
 *
 * Read a binary header from a file and parse into a SAC header
 * struct.  Also determines byte order and sets the swap flag unless
 * already dictated by the format.
 *
 * Returns 0 on sucess or -1 on failure.
 ***************************************************************************/
static int
readbinaryheader (FILE *ifp, struct SACHeader *sh, int *format,
		  int *swapflag, int verbose, char *sacfile)
{
  int bigendianhost;
  int32_t hdrver;
  
  /* Read the binary header into memory */
  if ( fread (sh, sizeof(struct SACHeader), 1, ifp) != 1 )
    {
      fprintf (stderr, "[%s] Could not read SAC header from file\n", sacfile);
      
      if ( ferror (ifp) )
	fprintf (stderr, "[%s] Error reading from file\n", sacfile);
      
      return -1;
    }
  
  /* Determine if host is big-endian */
  bigendianhost = ms_bigendianhost();
  
  *swapflag = 0;
  
  /* Test byte order using the header version if unknown */
  /* Also set the swapflag appropriately */
  if ( *format == 2 )
    {
      memcpy (&hdrver, &sh->nvhdr, 4);
      if ( hdrver < 1 || hdrver > 10 )
	{
	  ms_gswap4 (&hdrver);
	  if ( hdrver < 1 || hdrver > 10 )
	    {
	      fprintf (stderr, "[%s] Cannot determine byte order (not SAC?)\n", sacfile);
	      return -1;
	    }
	  
	  *format = ( bigendianhost ) ? 3 : 4;
	  *swapflag = 1;
	}
      else
	{
	  *format =  ( bigendianhost ) ? 4 : 3;
	}
    }
  else if ( *format == 3 && bigendianhost ) *swapflag = 1;
  else if ( *format == 4 && ! bigendianhost ) *swapflag = 1;
  
  if ( verbose > 1 )
    {
      if ( *swapflag )
	fprintf (stderr, "[%s] Byte swapping required\n", sacfile);
      else
	fprintf (stderr, "[%s] Byte swapping NOT required\n", sacfile);
    }
  
  /* Byte swap all values in header */
  if ( *swapflag )
    swapsacheader (sh);  
  
  return 0;
}  /* End of readbinaryheader() */


/***************************************************************************
 * readbinarydata:
 *
 * Read binary data from a file and add to an array, the array
 * must already be allocated with datacnt floats.
 *
 * Returns 0 on sucess or -1 on failure.
 ***************************************************************************/
static int
readbinarydata (FILE *ifp, float *data, int datacnt, int swapflag,
		int verbose, char *sacfile)
{
  int samplesread = 0;
  int dataidx;
  
  /* Read in data samples */
  if ( (samplesread = fread (data, sizeof(float), datacnt, ifp)) != datacnt )
    {
      fprintf (stderr, "[%s] Only read %d of %d expected data samples\n",
	       sacfile, samplesread, datacnt);
      return -1;
    }
  
  /* Swap data samples */
  if ( swapflag )
    {
      for ( dataidx = 0; dataidx < datacnt; dataidx++ ) 
	{
	  ms_gswap4 (data + dataidx);
	}
    }
  
  return 0;
}   /* End of readbinarydata() */


/***************************************************************************
 * readalphaheader:
 *
 * Read a alphanumeric header from a file and parse into a SAC header
 * struct.
 *
 * Returns 0 on sucess or a positive number indicating line number of
 * parsing failure.
 ***************************************************************************/
static int
readalphaheader (FILE *ifp, struct SACHeader *sh)
{
  char line[1025];
  int linecnt = 1;  /* The header starts at line 1 */
  int lineidx;
  int count;
  int hvidx = 0;
  char *cp;
  
  if ( ! ifp || ! sh )
    return -1;
  
  /* The first 14 lines x 5 values are floats */
  for (lineidx=0; lineidx < 14; lineidx++)
    {
      if ( ! fgets(line, sizeof(line), ifp) )
	return linecnt;
      
      count = sscanf (line, " %f %f %f %f %f ", (float *) sh + hvidx,
		      (float *) sh + hvidx + 1, (float *) sh + hvidx + 2,
		      (float *) sh + hvidx + 3, (float *) sh + hvidx + 4);
      
      if ( count != 5 )
	return linecnt;
      
      hvidx += 5;
      linecnt++;
    }
  
  /* The next 8 lines x 5 values are integers */
  for (lineidx=0; lineidx < 8; lineidx++)
    {
      if ( ! fgets(line, sizeof(line), ifp) )
	return linecnt;
      
      count = sscanf (line, " %d %d %d %d %d ", (int32_t *) sh + hvidx,
		      (int32_t *) sh + hvidx + 1, (int32_t *) sh + hvidx + 2,
		      (int32_t *) sh + hvidx + 3, (int32_t *) sh + hvidx + 4);
      
      if ( count != 5 )
	return linecnt;
      
      hvidx += 5;
      linecnt++;
    }
  
  /* Set pointer to start of string variables */
  cp =  (char *) sh + (hvidx * 4);
  
  /* The next 8 lines each contain 24 bytes of string data */
  for (lineidx=0; lineidx < 8; lineidx++)
    {
      memset (line, 0, sizeof(line));
      if ( ! fgets(line, sizeof(line), ifp) )
	return linecnt;
      
      memcpy (cp, line, 24);
      cp += 24;
      
      linecnt++;
    }
  
  /* Make sure each of the 23 string variables are left justified */
  cp =  (char *) sh + (hvidx * 4);  
  for (count=0; count < 24; count++)
    {
      int ridx, widx, width;
      char *fcp;
      
      /* Each string variable is 8 characters with one exception */
      if ( count != 1 )
	{
	  width = 8;
	}
      else
	{
	  width = 16;
	  count++;
	}
      
      /* Pointer to field */
      fcp = cp + (count * 8);

      /* Find first character that is not a space */
      ridx = 0;
      while ( *(fcp + ridx) == ' ' )
	ridx++;
      
      /* Remove any leading spaces */
      if ( ridx > 0 )
	{
	  for (widx=0; widx < width; widx++, ridx++)
	    {
	      if ( ridx < width )
		*(fcp + widx) = *(fcp + ridx);
	      else
		*(fcp + widx) = ' ';
	    }
	}
    }
  
  return 0;
}  /* End of readalphaheader() */


/***************************************************************************
 * readalphadata:
 *
 * Read a alphanumeric data from a file and add to an array, the array
 * must already be allocated with datacnt floats.
 *
 * Returns 0 on sucess or a positive number indicating line number of
 * parsing failure.
 ***************************************************************************/
static int
readalphadata (FILE *ifp, float *data, int datacnt)
{
  char line[1025];
  int linecnt = 31; /* Data samples start on line 31 */
  int samplesread = 0;
  int count;
  int dataidx = 0;
  
  if ( ! ifp || ! data || ! datacnt)
    return -1;
  
  /* Each data line should contain 5 floats unless the last */
  for (;;)
    {
      if ( ! fgets(line, sizeof(line), ifp) )
	return linecnt;
      
      count = sscanf (line, " %f %f %f %f %f ", (float *) data + dataidx,
		      (float *) data + dataidx + 1, (float *) data + dataidx + 2,
		      (float *) data + dataidx + 3, (float *) data + dataidx + 4);
      
      samplesread += count;
      
      if ( samplesread >= datacnt )
	break;
      else if ( count != 5 )
	return linecnt;
      
      dataidx += 5;
      linecnt++;
    }
  
  return 0;
}  /* End of readalphadata() */


/***************************************************************************
 * swapsacheader:
 *
 * Byte swap all multi-byte quantities (floats and ints) in SAC header
 * struct.
 *
 * Returns 0 on sucess and -1 on failure.
 ***************************************************************************/
static int
swapsacheader (struct SACHeader *sh)
{
  int32_t *ip;
  int idx;
  
  if ( ! sh )
    return -1;
  
  for ( idx=0; idx < (NUMFLOATHDR + NUMINTHDR); idx++ )
    {
      ip = (int32_t *) sh + idx;
      ms_gswap4 (ip);
    }
  
  return 0;
}  /* End of swapsacheader() */


/***************************************************************************
 * writemetadata:
 *
 * Write a single line of metadata into the metadata output file
 * containing the following fields comma-separated in this order:
 *
 *   Network (knetwk)
 *   Station (kstnm)
 *   Location (khole)
 *   Channel (kcmpnm)
 *   Latitude (stla)
 *   Longitude (stlo)
 *   Elevation (stel) [not currently used by SAC]
 *   Depth (stdp) [not currently used by SAC]
 *   Component Azimuth (cmpaz), degrees clockwise from north
 *   Component Incident Angle (cmpinc), degrees from vertical
 *   Instrument Name (kinst)
 *   Scale Factor (scale)
 *   Scale Frequency, unknown, will be empty
 *   Scale Units, unknown, will be empty
 *   Sampling rate, in samples per second (1/delta)
 *   Start time, set to start time
 *   End time, set to end time
 *
 * If the expanded argument is true the following fields will also be
 * included:
 *
 *   Event Name (kevnm)
 *   User string 0 (kuser0)
 *   User string 1 (kuser1)
 *   User string 2 (kuser2)
 *
 * Returns 0 on sucess and -1 on failure.
 ***************************************************************************/
static int
writemetadata (struct SACHeader *sh, hptime_t starttime, int expanded)
{
  static flag wroteheader = 0;
  hptime_t endtime;
  char network[9];
  char station[9];
  char location[9];
  char channel[9];
  char string[50];
  char *cp;
  
  if ( ! sh || ! mfp )
    return -1;
  
  if ( ! wroteheader )
    {
      wroteheader = 1;
      
      if ( ! fprintf (mfp, "#Net,Sta,Loc,Chan,Lat,Lon,Elev,Depth,Az,Inc,Inst,Scale,ScaleFreq,ScaleUnits,SampleRate,Start,End") )
	{
	  fprintf (stderr, "Error writing to metadata output file\n");
	  return -1;
	}
      
      if ( expanded )
	if ( ! fprintf (mfp, ",Event,String0,String1,String2") )
	  {
	    fprintf (stderr, "Error writing to metadata output file\n");
	    return -1;
	  }
      
      fprintf (mfp, "\n");
    }

  if ( strncmp (SUNDEF, sh->knetwk, 6) ) ms_strncpclean (network, sh->knetwk, 2);
  else network[0] = '\0';
  if ( strncmp (SUNDEF, sh->kstnm, 6) ) ms_strncpclean (station, sh->kstnm, 5);
  else station[0] = '\0';
  if ( strncmp (SUNDEF, sh->khole, 6) ) ms_strncpclean (location, sh->khole, 2);
  else location[0] = '\0';
  if ( strncmp (SUNDEF, sh->kcmpnm, 6) ) ms_strncpclean (channel, sh->kcmpnm, 3);
  else channel[0] = '\0';

  /* LINE: Net,Sta,Loc,Chan,Lat,Lon,Elev,Dep,Az,Inc,Inst,Scale,ScaleFreq,ScaleUnits,SampleRate,Start,End[,Event,String0,String1,String2] */
  
  /* Write the source parameters */
  if ( ! fprintf (mfp, "%s,%s,%s,%s,", network, station, location, channel) )
    {
      fprintf (stderr, "Error writing to metadata output file\n");
      return -1;
    }
  
  /* Write lat, lon, elev, depth, azimuth, incident and instrument, scale */
  if ( sh->stla != FUNDEF ) fprintf (mfp, "%.5f,", sh->stla);
  else fprintf (mfp, ",");
  if ( sh->stlo != FUNDEF ) fprintf (mfp, "%.5f,", sh->stlo);
  else fprintf (mfp, ",");
  if ( sh->stel != FUNDEF ) fprintf (mfp, "%g,", sh->stel);
  else fprintf (mfp, ",");
  if ( sh->stdp != FUNDEF ) fprintf (mfp, "%g,", sh->stdp);
  else fprintf (mfp, ",");
  if ( sh->cmpaz != FUNDEF ) fprintf (mfp, "%g,", sh->cmpaz);
  else fprintf (mfp, ",");
  if ( sh->cmpinc != FUNDEF ) fprintf (mfp, "%g,", sh->cmpinc);
  else fprintf (mfp, ",");
  if ( strncmp (SUNDEF, sh->kinst, 6) )
    {
      memcpy (string, sh->kinst, 8); string[8] = '\0';
      for (cp = &string[7]; cp >= string && *cp == ' '; cp-- ) { *cp = '\0'; }
      fprintf (mfp, "%s,", string);
    }
  else fprintf (mfp, ",");
  if ( sh->scale != FUNDEF ) fprintf (mfp, "%.g,", sh->scale);
  else fprintf (mfp, ",");
  
  /* Add blanks for ScaleFreq and ScaleUnits which we do not know */
  fprintf (mfp, ",,");
  
  /* Add sampling rate */
  if ( sh->delta != FUNDEF ) fprintf (mfp, "%g,", 1.0/sh->delta);
  else fprintf (mfp, ",");
  
  /* Add start time */
  ms_hptime2isotimestr (starttime, string, 0);
  fprintf (mfp, "%s,", string);
  
  /* Calculate and add end time */
  endtime = starttime + (hptime_t)((double)((sh->npts - 1) * sh->delta) * HPTMODULUS);
  ms_hptime2isotimestr (endtime, string, 0);
  fprintf (mfp, "%s", string);
  
  if ( expanded )
    {
      fprintf (mfp, ",");
      if ( strncmp (SUNDEF, sh->kevnm, 6) )
	{
	  memcpy (string, sh->kevnm, 16); string[16] = '\0';
	  for (cp = &string[15]; cp >= string && *cp == ' '; cp-- ) { *cp = '\0'; }
	  fprintf (mfp, "%s,", string);
	}
      else fprintf (mfp, ",");
      if ( strncmp (SUNDEF, sh->kuser0, 6) )
	{
	  memcpy (string, sh->kuser0, 8); string[8] = '\0';
	  for (cp = &string[7]; cp >= string && *cp == ' '; cp-- ) { *cp = '\0'; }
	  fprintf (mfp, "%s,", string);
	}
      else fprintf (mfp, ",");
      if ( strncmp (SUNDEF, sh->kuser1, 6) )
	{
	  memcpy (string, sh->kuser1, 8); string[8] = '\0';
	  for (cp = &string[7]; cp >= string && *cp == ' '; cp-- ) { *cp = '\0'; }
	  fprintf (mfp, "%s,", string);
	}
      else fprintf (mfp, ",");
      if ( strncmp (SUNDEF, sh->kuser2, 6) )
	{
	  memcpy (string, sh->kuser2, 8); string[8] = '\0';
	  for (cp = &string[7]; cp >= string && *cp == ' '; cp-- ) { *cp = '\0'; }
	  fprintf (mfp, "%s", string);
	}
    }
  
  fprintf (mfp, "\n");
  
  return 0;
}  /* End of writemetadata() */


/***************************************************************************
 * parameter_proc:
 * Process the command line parameters.
 *
 * Returns 0 on success, and -1 on failure.
 ***************************************************************************/
static int
parameter_proc (int argcount, char **argvec)
{
  int optind;

  /* Process all command line arguments */
  for (optind = 1; optind < argcount; optind++)
    {
      if (strcmp (argvec[optind], "-V") == 0)
	{
	  fprintf (stderr, "%s version: %s\n", PACKAGE, VERSION);
	  exit (0);
	}
      else if (strcmp (argvec[optind], "-h") == 0)
	{
	  usage();
	  exit (0);
	}
      else if (strncmp (argvec[optind], "-v", 2) == 0)
	{
	  verbose += strspn (&argvec[optind][1], "v");
	}
      else if (strcmp (argvec[optind], "-p") == 0)
	{
	  addnode (&headerlist, NULL, getoptval(argcount, argvec, optind++));
	}
      else if (strcmp (argvec[optind], "-a") == 0)
	{
	  allheaders = 1;
	}
      else if (strcmp (argvec[optind], "-b") == 0)
	{
	  bareflag = 1;
	}
      else if (strcmp (argvec[optind], "-d") == 0)
	{
	  dataflag = 1;
	}
      else if (strcmp (argvec[optind], "-D") == 0)
	{
	  dataflag = 2;
	}
      else if (strcmp (argvec[optind], "-tf") == 0)
        {
          timeformat = strtol (getoptval(argcount, argvec, optind++), NULL, 10);
        }
      else if (strcmp (argvec[optind], "-s") == 0)
	{
	  datastats = 1;
	}
      else if (strcmp (argvec[optind], "-m") == 0)
	{
	  metafile = getoptval(argcount, argvec, optind++);
	}
      else if (strcmp (argvec[optind], "-me") == 0)
	{
	  expmeta = 1;
	}
      else if (strcmp (argvec[optind], "-f") == 0)
	{
	  sacformat = strtoul (getoptval(argcount, argvec, optind++), NULL, 10);
	}
      else if (strncmp (argvec[optind], "-", 1) == 0 &&
	       strlen (argvec[optind]) > 1 )
	{
	  fprintf(stderr, "Unknown option: %s\n", argvec[optind]);
	  exit (1);
	}
      else
	{
	  addnode (&filelist, NULL, argvec[optind]);
	}
    }

  /* Make sure an input files were specified */
  if ( filelist == 0 )
    {
      fprintf (stderr, "No input files were specified\n\n");
      fprintf (stderr, "%s version %s\n\n", PACKAGE, VERSION);
      fprintf (stderr, "Try %s -h for usage\n", PACKAGE);
      exit (1);
    }

  /* Report the program version */
  if ( verbose )
    fprintf (stderr, "%s version: %s\n", PACKAGE, VERSION);

  /* Check the input files for any list files, if any are found
   * remove them from the list and add the contained list */
  if ( filelist )
    {
      struct listnode *prevln, *ln;
      char *lfname;
      
      prevln = ln = filelist;
      while ( ln != 0 )
	{
	  lfname = ln->data;
	  
	  if ( *lfname == '@' )
	    {
	      /* Remove this node from the list */
	      if ( ln == filelist )
		filelist = ln->next;
	      else
		prevln->next = ln->next;
	      
	      /* Skip the '@' first character */
	      if ( *lfname == '@' )
		lfname++;

	      /* Read list file */
	      readlistfile (lfname);
	      
	      /* Free memory for this node */
	      if ( ln->key )
		free (ln->key);
	      free (ln->data);
	      free (ln);
	    }
	  else
	    {
	      prevln = ln;
	    }
	  
	  ln = ln->next;
	}
    }

  return 0;
}  /* End of parameter_proc() */


/***************************************************************************
 * getoptval:
 * Return the value to a command line option; checking that the value is 
 * itself not an option (starting with '-') and is not past the end of
 * the argument list.
 *
 * argcount: total arguments in argvec
 * argvec: argument list
 * argopt: index of option to process, value is expected to be at argopt+1
 *
 * Returns value on success and exits with error message on failure
 ***************************************************************************/
static char *
getoptval (int argcount, char **argvec, int argopt)
{
  if ( argvec == NULL || argvec[argopt] == NULL ) {
    fprintf (stderr, "getoptval(): NULL option requested\n");
    exit (1);
    return 0;
  }
  
  /* Special case of '-o -' usage */
  if ( (argopt+1) < argcount && strcmp (argvec[argopt], "-o") == 0 )
    if ( strcmp (argvec[argopt+1], "-") == 0 )
      return argvec[argopt+1];
  
  if ( (argopt+1) < argcount && *argvec[argopt+1] != '-' )
    return argvec[argopt+1];
  
  fprintf (stderr, "Option %s requires a value\n", argvec[argopt]);
  exit (1);
  return 0;
}  /* End of getoptval() */


/***************************************************************************
 * readlistfile:
 *
 * Read a list of files from a file and add them to the filelist for
 * input data.  The filename is expected to be the last
 * space-separated field on the line.
 *
 * Returns the number of file names parsed from the list or -1 on error.
 ***************************************************************************/
static int
readlistfile (char *listfile)
{
  FILE *fp;
  char  line[1024];
  char *ptr;
  int   filecnt = 0;
  
  char  filename[1024];
  char *lastfield = 0;
  int   fields = 0;
  int   wspace;
  
  /* Open the list file */
  if ( (fp = fopen (listfile, "rb")) == NULL )
    {
      if (errno == ENOENT)
        {
          fprintf (stderr, "Could not find list file %s\n", listfile);
          return -1;
        }
      else
        {
          fprintf (stderr, "Error opening list file %s: %s\n",
		   listfile, strerror (errno));
          return -1;
        }
    }
  
  if ( verbose )
    fprintf (stderr, "Reading list of input files from %s\n", listfile);
  
  while ( (fgets (line, sizeof(line), fp)) !=  NULL)
    {
      /* Truncate line at first \r or \n, count space-separated fields
       * and track last field */
      fields = 0;
      wspace = 0;
      ptr = line;
      while ( *ptr )
	{
	  if ( *ptr == '\r' || *ptr == '\n' || *ptr == '\0' )
	    {
	      *ptr = '\0';
	      break;
	    }
	  else if ( *ptr != ' ' )
	    {
	      if ( wspace || ptr == line )
		{
		  fields++; lastfield = ptr;
		}
	      wspace = 0;
	    }
	  else
	    {
	      wspace = 1;
	    }
	  
	  ptr++;
	}
      
      /* Skip empty lines */
      if ( ! lastfield )
	continue;
      
      if ( fields >= 1 && fields <= 3 )
	{
	  fields = sscanf (lastfield, "%s", filename);
	  
	  if ( fields != 1 )
	    {
	      fprintf (stderr, "Error parsing file name from: %s\n", line);
	      continue;
	    }
	  
	  if ( verbose > 1 )
	    fprintf (stderr, "Adding '%s' to input file list\n", filename);
	  
	  addnode (&filelist, NULL, filename);
	  filecnt++;
	  
	  continue;
	}
    }
  
  fclose (fp);
  
  return filecnt;
}  /* End readlistfile() */


/***************************************************************************
 * addnode:
 *
 * Add node to the specified list.
 ***************************************************************************/
static void
addnode (struct listnode **listroot, char *key, char *data)
{
  struct listnode *lastlp, *newlp;
  
  if ( data == NULL )
    {
      fprintf (stderr, "addnode(): No file name specified\n");
      return;
    }
  
  lastlp = *listroot;
  while ( lastlp != 0 )
    {
      if ( lastlp->next == 0 )
        break;
      
      lastlp = lastlp->next;
    }
  
  newlp = (struct listnode *) malloc (sizeof (struct listnode));
  memset (newlp, 0, sizeof (struct listnode));
  if ( key ) newlp->key = strdup(key);
  else newlp->key = key;
  if ( data) newlp->data = strdup(data);
  else newlp->data = data;
  newlp->next = 0;
  
  if ( lastlp == 0 )
    *listroot = newlp;
  else
    lastlp->next = newlp;
  
}  /* End of addnode() */


/***************************************************************************
 * usage:
 * Print the usage message and exit.
 ***************************************************************************/
static void
usage (void)
{
  fprintf (stderr, "%s version: %s\n\n", PACKAGE, VERSION);
  fprintf (stderr, "Dump information from SAC formatted files\n\n");
  fprintf (stderr, "Usage: %s [options] file1 [file2 file3 ...]\n\n", PACKAGE);
  fprintf (stderr,
	   " ## Options ##\n"
	   " -V             Report program version\n"
	   " -h             Show this usage message\n"
	   " -v             Be more verbose, multiple flags can be used\n"
	   " -p header      Print specified header field, can be specified multiple times\n"
	   " -a             Print a list of all defined header values\n"
	   " -b             Print bare output without file name\n"
	   " -d             Print first 20 sample values\n"
	   " -D             Print all sample values\n"
	   " -tf format     Specify time format for data sample output\n" 
	   " -s             Print basic sample value statistics\n"
	   " -m metafile    Write common metadata output to file\n"
	   " -me            Write additional fields into the metadata output\n"
	   " -f format      Specify input SAC file format (default is autodetect):\n"
	   "                  0=autodetect, 1=alpha, 2=binary (detect byte order),\n"
	   "                  3=binary (little-endian), 4=binary (big-endian)\n"
	   "\n"
	   " file(s)        File(s) of SAC input data\n"
	   "                  If a file is prefixed with an '@' it is assumed to contain\n"
	   "                  a list of data files to be read\n"
	   "\n");
}  /* End of usage() */
