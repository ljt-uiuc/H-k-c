#!/usr/bin/env perl
#
# plot HK stacking result
#   input hk-stacking results from stdin
#
open(FOUT,">>std_before.out");
while(<STDIN>) {
     ($sta, $h, $kapa, $cxx, $cyy, $cxy, $min, $dev) = split;
     # plot H-k stack
     open(AAA,">junk.cpt");
        printf AAA "%6.4f 0 0 0 0.0 255 255 255\n",1.1*$min;
     close(AAA);
#    system("grd2cpt $sta/hk.grd > junk.cpt");
     system("gmtset TICK_LENGTH -0.2c");
     system("gmtset LABEL_OFFSET 0.01c");
     system("gmtset LABEL_FONT_SIZE 18p");
     system("gmtset ANNOT_OFFSET_PRIMARY 0.1c");
#     system("grdimage -JX8/4 -Y15 $sta/hk.grd -Cjunk.cpt -Ba10f5:\"H (km)\":/a0.1f0.05:@~k@~:WSne -K");
     system("grdimage -JX8/4 -Y15 $sta/hk.grd -Cjunk.cpt -Ba10f5/a0.1f0.05:@~k@~:WSne -K");

     $hk = `grdinfo $sta/hk.grd | grep Command | cut -d' ' -f 5`; chop($hk);
     ($aa,$minH,$maxH,$mink,$maxk) = split(/[R\/]/,$hk);

     $q1 = 0.5*($cxx-$cyy); $q2 = sqrt($q1*$q1+$cxy*$cxy);
     $qtheta = 0.5*atan2($cxy,$q1); if ($qtheta>1.5708) {$qtheta = $qtheta - 1.5708;}
     $q1 = 0.5*($cxx+$cyy) + $q2;
     $q1 = sqrt($dev/$q1);
     $q2 = 0.5*($cxx+$cyy) - $q2; if ($q2<0.01*$q1) {$q2=0.01*$q1;}
     $q2 = sqrt($dev/$q2);
     $dh = $q1*cos($qtheta); if ($q2*sin($qtheta)>$dh) {$dh=$q2*sin($qtheta);}
     $dk = $q2*cos($qtheta); if ($q1*sin($qtheta)>$dk) {$dk=$q1*sin($qtheta);}

     $ratioH=4/($maxH-$minH);$ratiok=2/($maxk-$mink);
     $cxx = $cxx/($ratioH*$ratioH);
     $cyy = $cyy/($ratiok*$ratiok);
     $cxy = $cxy/($ratioH*$ratiok);
     $s1 = 0.5*($cxx-$cyy); $s2 = sqrt($s1*$s1+$cxy*$cxy);
     $theta = 0.5*atan2($cxy,$s1)*180./3.14159;
     $s1 = 0.5*($cxx+$cyy) + $s2;
     $s2 = 0.5*($cxx+$cyy) - $s2;
     if ($s2<0.) {print STDERR "Warning: $s2<0\n";$s2=$s1*1.e-6;}
     open(PLT,"|psxy -JX $hk -O -K -Se -W4/255/255/255");
     printf PLT "%6.2f %8.4f %6.1f %s %s\n",$h,$kapa,$theta,4*sqrt($dev/$s1),4*sqrt($dev/$s2);
     close(PLT);
     open(PLT,"|pstext -JX -R0/1/0/1 -O");
     printf PLT "0.03 0.07 15 0 1 BL Before\n0.97 0.83 15 0 1 BR $sta %4.1f km/%4.2f\n0.97 0.7 14 0 1 BR (%3.1f/%4.2f)\n",$h,$kapa,$dh,$dk;
     $dhh=$dh;
     $dkk=$dk;
     print FOUT "$sta $h $kapa $dhh $dkk\n";
     close(PLT);
}
close(FOUT);
exit(0);
