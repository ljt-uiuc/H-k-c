#read SAC data between tmark+tmin and tmark+tmax (optional)
sub readSac () {
    my ($name,$tmin,$tmax,$tmark) = @_;
    my $byteswap = exists($ENV{BYTE_SWAP}); # unpack("h*",pack("s",1)) =~ /^1/;
    unless (open(SAC,$name)) {print STDERR "could not open SAC file $name\n";return ();}
    binmode(SAC);
    my $buf;
    # SAC head has 70f + 40i + 24c
    if (read(SAC,$buf,632)!=632) {print STDERR "read SAC header failed\n";return ();}
    $buf = &ByteSwap($buf, 440) if $byteswap;
    my @head = unpack('f70i88',$buf);
    if ($tmark) {
       $tmin+=$head[10+$tmark];
       $tmax+=$head[10+$tmark];
    }
    $tmin=$head[5] unless $tmin and $tmin>$head[5];
    $tmax=$head[6] unless $tmax and $tmax<$head[6];
    unless ($tmax>$tmin) {print STDERR "tmax=$tmax is less that tmin=$tmin\n";return (\@head);}
    my $n0 = sprintf("%d",($tmin-$head[5])/$head[0]+1);
    unless (seek(SAC, 4*$n0, 1)) {print STDERR "seek $n0 floats failed\n";return (\@head);}
    my $npts = sprintf("%d",($tmax-$tmin)/$head[0]+1);
    $npts = $head[79]-$n0 if $npts > $head[79]-$n0;
    if (read(SAC,$buf,4*$npts)!=4*$npts) {print STDERR "reading $npts out of $head[79] of data failed\n";return (\@head);}
    $buf = &ByteSwap($buf, 4*$npts) if $byteswap;
    my @data = unpack("f*",$buf);
    $head[5] = $tmin;
    $head[6] = $tmax;
    $head[79] = $npts;
    return (\@head,\@data);
}

# byte swap
sub ByteSwap {
    my ($buf,$n) = @_;
    my @buf = split(//,$buf);
    for(my $i=0;$i<$n;$i+=4) {
       @buf[$i,$i+1,$i+2,$i+3] = @buf[$i+3,$i+2,$i+1,$i];
    }
    join('',@buf);
}

1;
