/*******************************************************
	convert compressed (either steim1 or steim2,
	blocksize 512/4096 byte, containing up to 5 channels
	of data for 1 station) SEED format terrascope
	data to SAC format data.

	  Usage: sd2sac input_kdata_file -Gout_file [-O -S -E]

	It  will generate out_file.(channel names)

        Written by Lupei Zhu on the base of read_kdata.c
	of Shingle Watada. 08/14/95, Caltech
	modified 04/14/97	adding origin time, event/
				station locations options
	modified 07/14/99	fix a bug with .fracsec
	modified 10/27/99	fix a bug that assumes data begins
				following the 64-byte header.
	modified 06/14/2000	add remove gain option
********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "sac.h"
#include "seed.h"

#define MAX_CHANNEL_NUMBER	12

typedef int BOOLEAN;            /* BOOLEAN used for logical variables */
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif


/****** subroutines forward reference ******/
int	decode_steim(const char *, float *, int, int, int, int);
double	sample_rate(struct fixed_header);
double	t_diff(	struct time0	t2, struct time0	t1);

int main(int argc, char **argv) {
  int			fd, i, j,  ns, nch=0, blk_size, steim, hour, min;
  BOOLEAN		error = FALSE,
    origin_time=FALSE,
    station_loc=FALSE,
    event_loc=FALSE,
    input_file_exist = FALSE,
    out_file_exist = FALSE,
    com_lev = FALSE;
  char			station_name[6],
    out_file[128],
    input_file[128],
    detector[2];
  float			evla, evlo, evdp, stla, stlo, stdp, gain, sec;
  float                 *fpt;
  double		dt;
  struct time0		ot;
  char			blk[4096];
  struct fixed_header	fixHd;
  struct channel_data	chn[MAX_CHANNEL_NUMBER];
  int		tb, te, tt[MAX_CHANNEL_NUMBER];
  double	t_diff(struct time0, struct time0);
  SACHEAD	hd = sac_null;
  
  /* read from command line */
  for (i=1; !error && i < argc; i++) {
    if (argv[i][0] == '-' ) {
      switch(argv[i][1]) {
      case 'G':	/* output file name */
	out_file_exist = TRUE;
	strcpy(out_file, &argv[i][2]);
	break;
      case 'O':	/* origin time of event*/
	origin_time = TRUE;
	ns = sscanf(&argv[i][2],"%hu/%hu/%d/%d/%f",&ot.year,&ot.yday,&hour,&min,&sec);
	if ( ns != 5 ) {
	  fprintf(stderr,"wrong format of origin time\n");
	  error = TRUE;
	}
	ot.hour = hour;
	ot.min = min;
	ot.sec = (int) sec;
	ot.fracsec = (int) 10000*(sec - ot.sec);
	break;
      case 'S':	/* station location*/
	station_loc = TRUE;
	ns = sscanf(&argv[i][2],"%f/%f/%f/%f",&stla,&stlo,&stdp,&gain);
	if (ns < 2) {
	    fprintf(stderr,"wrong format of station location\n");
	    error = TRUE;
	} else {
	    if (ns<4) gain = 1.;
	    if (ns<3) stdp = 0.;
	}
	break;
      case 'E':	/* event location*/
	event_loc = TRUE;
	ns = sscanf(&argv[i][2],"%f/%f/%f",&evla,&evlo,&evdp);
	if ( ns < 2 ) {
	  fprintf(stderr,"wrong format of event location\n");
	  error = TRUE;
	} else if (ns == 2)
	  evdp = 0;
	break;
      case 'C': /* compression level*/
	com_lev =TRUE;
	steim = atoi(&argv[i][2]);
	break;
      default:
	error = TRUE;
      }
    } else {
      if (input_file_exist)
	error = TRUE;
      else {
	input_file_exist = TRUE;
	strcpy(input_file,argv[i]);
      }
    }
  }

  if( error || ! out_file_exist) {
    fprintf(stderr,"Usage: %s seed_filename_for_one_station -Goutput_name [-Oorigin_time -Sstation_location -Eevent_location]\n",argv[0]);
    return -1;
  }
  
  if( (fd = open(input_file,O_RDONLY,0)) < 0 ){
    fprintf(stderr,"Cannot open %s.\n",input_file);
    return -1;
  }

  /************** determine the block size ****************/
  lseek(fd, 518, SEEK_SET);
  read(fd,&detector[0],2);
  blk_size=4096;
  if (detector[0] == 'D' && detector[1] == ' ') blk_size=512;


  /*********** read data and decompress them ************/

  lseek(fd, 0, SEEK_SET);
  while ( read(fd,&blk,blk_size) ) {

    memcpy(&fixHd, blk, sizeof(struct fixed_header));
    strncpy(station_name,fixHd.station_char,5);
    station_name[5]='\0';
    dt = sample_rate(fixHd);

    /**** find out the channel number *****/
    for(i=0;i<nch;i++)
      if( strncmp(chn[i].name,fixHd.channel_char, 3)==0 ) break;

    if ( nch == i ) { /* beginning of a new channel */
      if( ++nch > MAX_CHANNEL_NUMBER ){
        fprintf(stderr,"%s %d channels in the file excede limit\n",station_name,nch);
        nch--;
	break;
      }
      chn[i].ns = 0;
      strncpy(chn[i].name,fixHd.channel_char,3);
      chn[i].name[3]='\0';
      chn[i].t0 = fixHd.time;
      chn[i].data = NULL;
    }

    /* looking for gap */
    if (fabs(t_diff(fixHd.time,chn[i].t0) - dt*chn[i].ns) > 0.5*dt) {
      fprintf(stderr,"time gap exists for %s %s\n",station_name,chn[i].name);
/*      break;*/
    }

    ns = fixHd.nsamples;
    if( (fpt = (float *) realloc((char *) chn[i].data ,sizeof(float)*(chn[i].ns+ns))) == NULL ) {
      fprintf(stderr,"%s cannot allocate memeory.\n",station_name);
      break;
    }

    if (!com_lev) steim = fixHd.com_level;
    if (decode_steim(blk, fpt+chn[i].ns, ns, blk_size, fixHd.nbegin_data, steim) < 0)
      break;

    chn[i].ns += ns;
    chn[i].data = fpt;

  }

  close(fd);

  /* output data in SAC format */

  /** some defaut header values*/
  hd.iftype = ITIME;
  hd.leven = TRUE;
  hd.internal4 = 6;
  hd.internal5 = 0;
  hd.internal6 = 0;
  hd.lpspol = FALSE;
  hd.lcalda = TRUE;
  hd.unused27 = FALSE;
  /** end of default header values**/

  strcpy(hd.kstnm, station_name);
  hd.delta = dt;

  /** reference time **/
  if (!origin_time) {
    ot = chn[0].t0;
  }
  else {
    hd.o = 0.;
  }
  hd.nzyear = ot.year;
  hd.nzjday = ot.yday;
  hd.nzhour = ot.hour;
  hd.nzmin = ot.min;
  hd.nzsec = ot.sec;
  hd.nzmsec = 0.1*ot.fracsec;

  /* find the common time window of all channels */
  for(i=0;i<nch;i++) {
    tt[i] = (int) (t_diff(chn[i].t0, ot)/dt);
  }
  tb = tt[0];
  te = tb + chn[0].ns;
  for(i=1;i<nch;i++) {
    if (tb < tt[i]) tb = tt[i];
    if (te > chn[i].ns+tt[i]) te = chn[i].ns+tt[i];
  }
  hd.b = tb*dt;
  hd.npts = te - tb;
  if (hd.npts < 2) {
    fprintf(stderr,"no data read\n");
    return -1;
  }

  if (station_loc) {
    hd.stla = stla;
    hd.stlo = stlo;
    hd.stdp = hd.stel = stdp;
  }

  if (event_loc) {
    hd.evla = evla;
    hd.evlo = evlo;
    hd.evdp = hd.evel = evdp;
  }

  for (i=0;i<nch;i++) {
    switch (chn[i].name[2]) {
    case 'Z': case 'z':
      hd.cmpaz = 0.;
      hd.cmpinc = 0.;
      strcpy(hd.kcmpnm,"Up");
      break;
    case 'N': case 'n':
      hd.cmpaz = 0.;
      hd.cmpinc = 90.;
      strcpy(hd.kcmpnm,"North");
      break;
    case 'E': case 'e':
      hd.cmpaz = 90.;
      hd.cmpinc = 90.;
      strcpy(hd.kcmpnm,"East");
    }

    for(fpt=chn[i].data,j=0;j<chn[i].ns;j++,fpt++) *fpt = (*fpt)/gain;
    strcat(strcat(strcpy(input_file,out_file),"."), chn[i].name);
    if (write_sac(input_file,hd,chn[i].data+tb-tt[i]) < 0 )
      return -1;

  }

  return 0;

}



int	decode_steim (
		      const char	*buff,
		      float		*data,
		      int		ns,
		      int		blk_size,
		      int		dataOffset,
		      int		steim
		      )
{
  int	i,j,nFrame,nd,x0,xn,w0,dumint,a[8],*diff;
  union	dd {
    int		integer;
    short int	short_int[2];
    char	chars[4];
  } *d;

  if (steim < 0 || steim > 2 ) {
    fprintf(stderr, "unknown compression level %d\n",steim);
    return -1;
  }
  
  if ( (diff = (int *) malloc(sizeof(int)*blk_size)) == NULL ) {
    fprintf(stderr, "error in allocating memory\n");
    return -1;
  }

  /* decode frame */
  d = (union dd *) (buff+dataOffset);
  x0 = d[1].integer;
  xn = d[2].integer;
  nd = 0;
  for (nFrame=dataOffset/64; nFrame<blk_size/64; nFrame++) {
    w0 = d->integer;
    if ( ( (w0>>(15-0)*2) & 03 ) != IS_SPECIAL ) {
      fprintf(stderr,"non-special decode key for w0\n");
      return -1;
    }
    d++;
    for(j=1;j<16;j++,d++){

      switch( (w0>>(15-j)*2) & 03 ) {

      case IS_SPECIAL:
	break;

      case IS_ONE_BYTE:
	for (i=0;i<4;i++) diff[nd++]=d->chars[i];
	break;

      case IS_TWO_BYTES:
	if (steim == 0 || steim == 1)
	  for (i=0;i<2;i++) diff[nd++]=d->short_int[i];
	else {
	  dumint = d->integer;
	  switch(GET_DNIB(dumint)){
	  case IS_1_30BITS:
	    DCM_1_30BITS(dumint,a);
	    diff[nd++]=a[0];
	    break;
	  case IS_2_15BITS:
	    DCM_2_15BITS(dumint,a);
	    for (i=0;i<2;i++) diff[nd++]=a[i];
	    break;
	  case IS_3_10BITS:
	    DCM_3_10BITS(dumint,a);
	    for (i=0;i<3;i++) diff[nd++]=a[i];
	  }
	}
	break;

      case IS_FOUR_BYTES:
	if (steim == 0 || steim == 1) diff[nd++]=d->integer;
	else {
	  dumint = d->integer;
	  switch(GET_DNIB(dumint)){
	  case IS_5_6BITS:
	    DCM_5_6BITS(dumint,a);
	    for (i=0;i<5;i++) diff[nd++]=a[i];
	    break;
	  case IS_6_5BITS:
	    DCM_6_5BITS(dumint,a);
	    for (i=0;i<6;i++) diff[nd++]=a[i];
	    break;
	  case IS_7_4BITS:
	    DCM_7_4BITS(dumint,a);
	    for (i=0;i<7;i++) diff[nd++]=a[i];
	  }
	}
      }

    }

  }

  data[0]=x0;
  for(i=1;i<ns;i++) {
    x0+=diff[i];
    data[i]=x0;
  }

  free(diff);

  if( x0 != xn ) {
    fprintf(stderr,"Inconsistent data: ns=%d nd=%d last=%d xn=%d\n",ns,nd,x0,xn);
    return 0;
  }

  return 0;

}


/* time difference t2-t1 (in sec). assuming both in the same year */
double	t_diff(
	       struct time0	t2,
	       struct time0	t1
	       )
{
  return (double)((((((int)(t2.yday-t1.yday))*24 +
		     (int)(t2.hour-t1.hour))*60 +
		    (int)(t2.min-t1.min))*60 +
		   (int)(t2.sec-t1.sec))*10000 +
		  (int)(t2.fracsec-t1.fracsec))*0.0001;
}



double	sample_rate(struct fixed_header f_hd)
{
  return (f_hd.rate > 0 ? 1.0/(double)f_hd.rate : -f_hd.rate) *
    (f_hd.mult > 0 ? 1.0/(double)f_hd.mult : -f_hd.mult);
}
