/********************************************************
* Pick arrival time using STA/LTA method
********************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "sac.h"

int main(int argc, char **argv) {
  int		i, j, win, error, triggered;
  float		t1, t2, sta, lta, t, t0, c1, c2, dum, *ar;
  char		outf[128];
  SACHEAD	hd;

  float st = 0.5;
  float lt = 10.;
  float thr = 5.;
  float pre = 2*lt;
  int save = 0;
  win = 0;
  error = 0;
  for (j=1; !error && j < argc; j++) {
     if (argv[j][0] == '-') {
        switch(argv[j][1]) {
	case 'L':
	    i = sscanf(&argv[j][2], "%f/%f/%f",&st,&c1,&c2);
	    if (i>1) lt=c1;
	    if (i>2) pre=c2;
	    break;
	case 'S':
	    save = 1;
	    break;
	case 'T':
	    sscanf(&argv[j][2], "%f",&thr);
	    break;
	case 'W':
	    win = 1;
            sscanf(&argv[j][2], "%f/%f",&t1,&t2);
	    break;
	default:
	    error = 1;
	}
     }
  }
  if (argc == 1 || error) {
     fprintf(stderr, "Usage: sacTrig [-Lst[/lt[/pre]]] [-Threshold] [-Wt1/t2] sac_files ...\n\
		-L  specify short-term and long-term durations in sec. (%4.1f/%4.1f/%4.1f)\n\
		-S  save the STA/LTA ratios (off) \n\
		-T  specify STA/LTA triggering threshold. (%4.1f) \n\
		-W  specify triggering time window (off)\n\
	Output: name trigger time\n",st,lt,pre,thr);
     return -1;
  }

  while(*(++argv)) {
     if (argv[0][0] == '-' || (ar = read_sac(*argv,&hd)) == NULL) continue;
     sta = 0.;
     lta = 0.;
     c1 = hd.delta/st;
     c2 = hd.delta/lt;
     triggered = 0;
     t0 = -12345.;
     for(t=hd.b,j=0;j<hd.npts;j++,t+=hd.delta) {
	dum = fabs(ar[j]);
        sta = (1.-c1)*sta + c1*dum;
	lta = (1.-c2)*lta + c2*dum;
	if (t<hd.b+pre) continue;
	ar[j] = sta/lta;
	if ( !triggered && ar[j]>thr && (!win || (t>t1&&t<t2)) ) {
	   triggered = 1;
	   t0 = t-st;
        }
	if ( triggered && !save ) break;
     }
     printf("%s %9.2f\n", *argv,t0);
     if (save) {
	strcpy(outf, *argv); strcat(outf,".ratio");
        write_sac(outf,hd,ar);
     }
     free(ar);
  }

  return 0;
}
