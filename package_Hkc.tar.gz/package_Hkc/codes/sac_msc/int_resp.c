#include <stdio.h>

main(int argc, char **argv) {
float freq_inc,freq;
float nyquist;
int nf,num_poles,num_zeros,i,j,anump;
double save,amp,maxamp=(0.0e-304);
d_complex omega,denum,num,temp,gain;

	fscanf("%s %d",&num_zeros);
	for(i=0;i<num_zeros,i++) fscanf("%f %f",&zero[i].x,&zero[i].y);

	num_poles=(int)(head_pt->station.cal[0].pole.r);
	num_zeros=(int)(head_pt->station.cal[0].zero.r);

/*	get nearest power of 2 thats at least twice the data length */

	for(i=1;((int)pow((double)2,(double)i))<(head_pt->record.ndata);++i);
	anump=(int)pow((double)2,(double)(i+1));

/*	calculate nyquist, number of frequency points, and frequency interval */

	nyquist=1.0/(2.0*(head_pt->record.delta));
	nf=(int)(anump/(2.0)+1);
	freq_inc=nyquist/(float)(nf-1.0);
	gain.i=0.0;
	gain.r=(double)(head_pt->station.A0);     /* A0 */
	gain.r*=(double)(head_pt->station.DS);   /* DS */

/* loop through frequencies and calculate response */

	for(freq=0.0,j=0;j<nf;freq+=freq_inc,++j)
	{
		omega.i=freq*2.0*3.1415926;	
		omega.r=0.0;
		denum.r=denum.i=num.r=num.i=1.0;

		for(i=1;i<=num_poles;++i)
		{
			/* denum=denum*(omega-pole[i]) */
			temp.r=omega.r-(double)head_pt->station.cal[i].pole.r;
			temp.i=omega.i-(double)head_pt->station.cal[i].pole.i;
			save=denum.r*temp.r-denum.i*temp.i;
			temp.i=denum.r*temp.i+denum.i*temp.r;
			temp.r=save;
			denum.r=temp.r;
			denum.i=temp.i;
		}
		for(i=1;i<=num_zeros;++i)
		{
			/* num=num*(omega-zero[i]) */
			temp.r=omega.r-(double)head_pt->station.cal[i].zero.r;
			temp.i=omega.i-(double)head_pt->station.cal[i].zero.i;
			save=num.r*temp.r-num.i*temp.i;
			temp.i=num.r*temp.i+num.i*temp.r;
			temp.r=save;
			num.r=temp.r;
			num.i=temp.i;
		}
		/* gain*num */
		save=gain.r*num.r;
		num.i=gain.r*num.i;
		num.r=save;

		/* num/denum */
		temp.r=num.r*denum.r+num.i*denum.i;
		temp.i=num.i*denum.r-num.r*denum.i;
		save=denum.r*denum.r+denum.i*denum.i;
		temp.r/=save;
		temp.i/=save;

		/* find maximum amplitude */
		amp=temp.r*temp.r+temp.i*temp.i;
		if(amp > maxamp)maxamp=amp;
		response[j].r=temp.r;
		response[j].i=temp.i;
	}
	maxamp=sqrt(maxamp);
	return(maxamp);
