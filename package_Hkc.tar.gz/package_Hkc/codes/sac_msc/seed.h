#define IS_CALIBRATION          0x0001
#define IS_TIME_CORRECTION      0x0002
#define IS_BEGINNIG_OF_EVENT    0x0004
#define IS_END_OF_EVENT         0x0008
#define IS_POSITIVE_LEAP_SECOND 0x0010
#define IS_NEGATIVE_LEAP_SECOND 0x0020
#define IS_EVENT_IN_PROGRESS    0x0040

#define IS_STAION_PARITY        0x0001
#define IS_LONG_RECORD          0x0002
#define IS_SHORT_RECORD         0x0004

#define IS_AMPILFIER_SATURATED  0x0001
#define IS_DIGITIGER_CLIPPED    0x0002
#define IS_SPIKE_DETECTED       0x0004
#define IS_GLITCH_DETECTED      0x0008
#define IS_MISSING_PADDING_DATA 0x0010
#define IS_TELEMETRY_SYNC_ERROR 0x0020
#define IS_FILETER_CHARGING     0x0040
#define IS_TIMETAG_QUESTIONABLE 0x0080

#define IS_SPECIAL              0x0000
#define IS_ONE_BYTE             0x0001
#define IS_TWO_BYTES            0x0002
#define IS_FOUR_BYTES           0x0003

#define GET_DNIB(x)             ((x)>>30&0x3)
#define IS_1_30BITS             0x1
#define IS_2_15BITS             0x2
#define IS_3_10BITS             0x3
#define IS_5_6BITS              0x0
#define IS_6_5BITS              0x1
#define IS_7_4BITS              0x2

#define DCM_1_30BITS(x,a)       a[0]=((x)&0x20000000 ? ((x)&0x3fffffff)-0x40000000 : (x)&0x2fffffff)
#define DCM_2_15BITS(x,a)       a[1]=((x)&0x00004000 ? ((x)&0x00007fff)-0x00008000 : (x)&0x00003fff); (x)>>=15; \
					  a[0]=((x)&0x00004000 ? ((x)&0x00007fff)-0x00008000 : (x)&0x00003fff)
#define DCM_3_10BITS(x,a)       a[2]=((x)&0x00000200 ? ((x)&0x000003ff)-0x00000400 : (x)&0x000001ff); (x)>>=10; \
                                a[1]=((x)&0x00000200 ? ((x)&0x000003ff)-0x00000400 : (x)&0x000001ff); (x)>>=10; \
                                a[0]=((x)&0x00000200 ? ((x)&0x000003ff)-0x00000400 : (x)&0x000001ff);
#define DCM_5_6BITS(x,a)        a[4]=((x)&0x00000020 ? ((x)&0x0000003f)-0x00000040 : (x)&0x0000001f); (x)>>=6; \
                                a[3]=((x)&0x00000020 ? ((x)&0x0000003f)-0x00000040 : (x)&0x0000001f); (x)>>=6; \
                                a[2]=((x)&0x00000020 ? ((x)&0x0000003f)-0x00000040 : (x)&0x0000001f); (x)>>=6; \
                                a[1]=((x)&0x00000020 ? ((x)&0x0000003f)-0x00000040 : (x)&0x0000001f); (x)>>=6; \
                                a[0]=((x)&0x00000020 ? ((x)&0x0000003f)-0x00000040 : (x)&0x0000001f);
#define DCM_6_5BITS(x,a)        a[5]=((x)&0x00000010 ? ((x)&0x0000001f)-0x00000020 : (x)&0x0000000f); (x)>>=5; \
                                a[4]=((x)&0x00000010 ? ((x)&0x0000001f)-0x00000020 : (x)&0x0000000f); (x)>>=5; \
                                a[3]=((x)&0x00000010 ? ((x)&0x0000001f)-0x00000020 : (x)&0x0000000f); (x)>>=5; \
                                a[2]=((x)&0x00000010 ? ((x)&0x0000001f)-0x00000020 : (x)&0x0000000f); (x)>>=5; \
                                a[1]=((x)&0x00000010 ? ((x)&0x0000001f)-0x00000020 : (x)&0x0000000f); (x)>>=5; \
                                a[0]=((x)&0x00000010 ? ((x)&0x0000001f)-0x00000020 : (x)&0x0000000f);
#define DCM_7_4BITS(x,a)        a[6]=((x)&0x00000008 ? ((x)&0x0000000f)-0x00000010 : (x)&0x00000007); (x)>>=4; \
                                a[5]=((x)&0x00000008 ? ((x)&0x0000000f)-0x00000010 : (x)&0x00000007); (x)>>=4; \
                                a[4]=((x)&0x00000008 ? ((x)&0x0000000f)-0x00000010 : (x)&0x00000007); (x)>>=4; \
                                a[3]=((x)&0x00000008 ? ((x)&0x0000000f)-0x00000010 : (x)&0x00000007); (x)>>=4; \
                                a[2]=((x)&0x00000008 ? ((x)&0x0000000f)-0x00000010 : (x)&0x00000007); (x)>>=4; \
                                a[1]=((x)&0x00000008 ? ((x)&0x0000000f)-0x00000010 : (x)&0x00000007); (x)>>=4; \
                                a[0]=((x)&0x00000008 ? ((x)&0x0000000f)-0x00000010 : (x)&0x00000007); 

struct time0 {
	unsigned short int	year, yday;
	unsigned char		hour, min, sec, dum;
	unsigned short int	fracsec; /* 1fracsec=1e-4sec */
};

struct channel_data {
	char	name[4];
	float	*data;
	int	ns;
	struct time0 t0;
};

struct fixed_header {
	char		sequence_char[6],
	     		char_D,
	     		char_null1,
	     		station_char[5],
	     		location_char[2],
	     		channel_char[3],
	     		network_char[2]; /* new SEED version 2.3 */
	struct time0	time;
	unsigned short int nsamples;
	short int	rate;
	short int	mult;
	char		activityflag,
	     		ioflag,
	     		qualityflag,
	     		nblockets;
	long int	timecorrection;	/* unit 1e-4 sec. Add this
					amount to time to get
					corrected time*/
	unsigned short int nbegin_data,
			nbegin_blocket;
        char		char_null2[7];
	char		com_level;	/*compression_level, this is a
					hidden parameter not
					described in the SEED manual!
					found from fortran decode
					program provoded by Steim.
					For relatively new data,
					this parameter is correct.
					in old data
					(eg. 900908203200.gsc.lp.k.0)
					this parameter is just zero.
					I do not know when this
					parameter became in use.
					October 6, 1993 */
	char		char_null3[8];
};
