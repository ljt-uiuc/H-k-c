/************************************************************
*	List the SAC header fields
*	Usage
*		saclst header_variable_names ... f sac_files
*	Lupei Zhu	5/4/1995 Caltech
*************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "sac.h"

int main(int argc, char **argv)
{
  int		i,j,ls[40],nl;
  float		*pt;
  char		sac_file[128];
  SACHEAD	hd;

  if(argc<2) {
      fprintf(stderr,"Usage: saclst header_lists f sac_file ...\n");
      return 0;
  }

  nl=0;argv++;argc--;
  while ( argc && *argv[0] != 'f' ) {
     ls[nl] = sac_head_index(argv[0]);
     if (ls[nl]<0) {
	fprintf(stderr, "error in header_list  %s\n",argv[0]);
	return -1;
     }
     nl++; argv++; argc--;
  }

  i = 0;
  while( (argc>1 && ++i<argc && strcpy(sac_file, argv[i]))
      || (argc<1 && fgets(sac_file,128,stdin)) ) {
      if ( read_sachead(sac_file, &hd) != -1) {
        printf("%s ",sac_file);
	pt = (float *) &hd;
        for (j=0;j<nl;j++) {
	  if ((ls[j]>39 && ls[j]<50) || (ls[j]>0 && ls[j]<3) || ls[j]==56)
	     printf("%10.2e",pt[ls[j]]);
	  else if (ls[j]<70)
	     printf("%12.4f",pt[ls[j]]);
	  else if (ls[j]<76)
	     printf("%5d %3d %2d %2d %5.2f",hd.nzyear,hd.nzjday,hd.nzhour,hd.nzmin,hd.nzsec+0.001*hd.nzmsec);
	  else if (ls[j]<110)
	     printf("%8d",hd.npts);
          else {
	     hd.kstnm[8]='\0';
             printf("%8s",hd.kstnm);
          }
        }
        printf("\n");
      }
  }

  return 0;

}
