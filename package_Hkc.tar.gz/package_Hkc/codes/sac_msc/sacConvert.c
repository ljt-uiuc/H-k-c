/********************************************************
*	convert sac from/into PC/Sun format
*		sacConvert [-A] [-r] sac_files ...
* revised history:
*    2008/05/27  LZ	fix a bug that did swap for SAC head char members
********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sac.h"

int main(int argc, char **argv) {
  SACHEAD	hd;
  int		i,sz,error=0,reverse=0,ow=1;
  float		*data;
  char		fnm[128],ext[32];
  FILE		*strm;
  size_t swapRead(void *, size_t,  FILE *, int);
  size_t swapWrite(void *, size_t,  FILE *, int);

  for (i=1; !error && i < argc; i++) {
    if (argv[i][0] == '-') {
       switch(argv[i][1]) {
       case 'r':
	  reverse=1;
	  break;
       case 'A':
	  ow = 0;
          strcpy(ext,&argv[i][2]);
	  if (ext[0] == '\0') strcpy(ext, "cvt");
	  break;
       default:
          error = 1;
       }
    }
  }
  if (argc == 1 || error) {
     fprintf(stderr, "Usage: %s [-Astring] [-r] sac_files ...\n \
  convert SAC file from the current byte-order to the other byte-order\n\
    -A: creat new file by appending string to the original sac file name\n\
    -r: do the reverse conversion\n",argv[0]);
     return -1;
  }

  for (i=1;i<argc;i++) {
     if (argv[i][0] == '-') continue;
     fprintf(stderr,"%s\n",argv[i]);
     strcpy(fnm,argv[i]);
     if (!ow) strcat(strcat(fnm,"."),ext);
     if (reverse) {
        if ( (strm = fopen(argv[i], "rb")) == NULL ||
             swapRead(&hd, sizeof(SACHEAD), strm, 1) != 1 ||
	     (data = (float *) malloc(hd.npts*sizeof(float))) == NULL || 
	     swapRead(data, hd.npts*sizeof(float), strm, 0) != 1 ) {
           fprintf(stderr,"Error in reading\n");
	   continue;
        }
	write_sac(fnm,hd,data);
     } else {
        if ( (data=read_sac(argv[i], &hd))==NULL ) continue;
	sz = hd.npts*sizeof(float);
        if ( (strm = fopen(fnm, "w")) == NULL ||
             swapWrite(&hd, sizeof(SACHEAD), strm, 1) != 1 ||
	     swapWrite(data, sz, strm, 0) != 1 ) {
           fprintf(stderr,"Error in writing\n");
        }
     }
     fclose(strm);
     free(data);
  }

  return 0;
}

size_t swapRead(void *ptr, size_t  size,  FILE *stream, int header) {
  size_t i;
  i = fread(ptr, size,  1,  stream);
#ifndef BYTE_SWAP
  if (header) swab4((char *) ptr, HD_SIZE);
  else swab4((char *) ptr, size);
#endif
  return i;
}

size_t swapWrite(void *ptr, size_t size,  FILE *stream, int header) {
#ifndef BYTE_SWAP
  if (header) swab4((char *) ptr, HD_SIZE);
  else swab4((char *) ptr, size);
#endif
  return fwrite(ptr, size,  1,  stream);
}
