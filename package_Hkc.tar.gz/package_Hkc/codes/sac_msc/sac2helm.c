/********************************************************
	Convert SAC format to Helmberger format
	Usage:
		sac2helm sac_formated_data ...
********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "sac.h"

int main(int argc, char **argv) {
  int	i,j;
  float	*a;
  SACHEAD	hd;

  if (argc < 2) {
     fprintf(stderr, "Usage: %s sac_formated_data ...\n",argv[0]);
     return -1;
  }

  printf("%d\n(1e11.4)\n",argc-1);
  for(i=1;i<argc;i++){
	if ( (a = read_sac(argv[i],&hd)) == NULL) {
	   return -1;
	}
        printf("%f %f\n%d %f\n",hd.dist,hd.b,hd.npts,hd.delta);
        for(j=0;j<hd.npts;j++)
           printf("%11.4e\n",a[j]);
	free(a);
  }

  return 0;

}
