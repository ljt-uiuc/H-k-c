/* band-pass filtering SAC traces using butterworth filters */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "sac.h"

int main(int argc, char **argv) {
   int i,m,n,nx,error;
   char fnm[64];
   float dt,f1,f2,fl,fh,fs,eps,ap,as,gn,h[100];
   float *x;
   SACHEAD hd;

   eps = 0.3;
   ap = 0.1;
   as = 0.1;
   f1 = 0.;
   f2 = 0.;
   ap=sqrt(ap/(1.-ap));
   as=sqrt((1.-as)/as);
   for (i=1; !error && i < argc; i++) {
       if (argv[i][0] == '-') {
          switch(argv[i][1]) {
             case 'C':
                sscanf(&argv[i][2],"%f/%f",&f1,&f2);
	        break;
             case 'E':
                sscanf(&argv[i][2],"%f",&eps);
	        break;
             default:
                error = TRUE;
          }
       }
   }

   if (argc == 1 || error || f2 == 0.) {
      fprintf(stderr,"usage: %s -Cf1/f2 [-Eeps] sac_files\n",argv[0]);
      return -1;
   }

   i = 0;
   error = 1;
   while ( ++i<argc ) {
      if (argv[i][0] == '-') continue;
      strcpy(fnm, argv[i]);
      if ( (x=read_sac(fnm,&hd)) == NULL ) continue;
      nx = hd.npts;
      dt = hd.delta;
      fl = f1*dt;
      fh = f2*dt;
      fs=fh*(1.+eps);
      butpas_(h,&m,&gn,&n,&fl,&fh,&fs,&ap,&as);
      printf("%d %d %f\n",m,n,gn);
   
      tandem_(x,x,&nx,h,&m,&gn,&error);
      strcat(fnm, ".flt");
      write_sac(fnm,hd,x);
      free(x);
   }

   return(0);
}
