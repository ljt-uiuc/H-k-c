/********************************************************
*	remove glitches of SAC trace
*	usage:
*		sac_rg threshold sac_files
*********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "sac.h"

int main(int argc, char **argv) {
  int i,j,k,ii;
  float *r,v,a0,slope;
  SACHEAD hd;
  char	temp[128];

  if (argc < 3) {
     fprintf(stderr,"Usage: %s threshold files\n",argv[0]);
     return 1;
  }
  sscanf(argv[1],"%f",&v);

  for(i=2;i<argc;i++) {
    strcpy(temp,argv[i]);
    fprintf(stderr,"%s\n",temp);
    if ( (r=read_sac(temp,&hd)) == NULL) continue;
    j=0;
    while( j < hd.npts ) {
      if (fabs(r[j]) < v) {
	 j++;
      } else {
	 k = j;
         while (j<hd.npts && fabs(r[j]) > v) j++;
         if (k==0) {
	    slope = 0;
	    if (j==hd.npts) a0 = 0; else a0=r[j];
	 } else {
	    a0 = r[k-1];
	    if (j==hd.npts) slope=0.; else slope=(r[j]-a0)/(j-k);
	 }
	 fprintf(stderr,"glitch between %d -> %d\n",k,j);
	 r[k] = a0+slope;
         for(ii=k+1;ii<j;ii++) r[ii] = r[ii-1]+slope;
      }
    }
    write_sac(strcat(temp,".rg"),hd,r);
    free(r);
  }

  return 0;

}
