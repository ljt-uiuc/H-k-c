/********************************************************
*	Compute Fourier spectrum amplitude of sac traces
*	Usage:
*		sacFFT [options] sac_files ...
********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Complex.h"
#include "sac.h"

int main(int argc, char **argv) {
  SACHEAD	hd;
  char		fnm[128];
  int		i, j, nn, nft, nft2, error, cut, tmark;
  float		*data, *wndw;
  complex	*spec;
  float		tBefore, tAfter, dt, df, w, fmax, fniq;

  w=0.2;
  cut = 0;
  error=0;
  fmax = -1.;
  /* input parameters */
  for (i=1; !error && i<argc && argv[i][0]=='-'; i++) {
     switch(argv[i][1]) {
       case 'C':
	  cut = 1;
  	  sscanf(argv[i]+2,"%d/%f/%f",&tmark,&tBefore,&tAfter);
	  break;
       case 'F':
  	  sscanf(argv[i]+2,"%f",&fmax);
	  break;
       case 'T':
          sscanf(argv[i]+2,"%f",&w);
	  break;
       default:
         error = 1;
     }
  }
  if (argc == 1 || error) {
     fprintf(stderr, "Usage: %s [-Ctmark/t1/t2] [-Fmax] [-Ttaper (%f)] sac_files ...\n",argv[0],w);
     return -1;
  }

  for (;i<argc;i++) {
     fprintf(stderr,"%s\n",argv[i]);

     if ( (cut && (data=read_sac2(argv[i], &hd, tmark, tBefore, tAfter))==NULL) ||
                  (data=read_sac(argv[i], &hd))==NULL ) continue;
     nn = hd.npts;
     dt = hd.delta;
     nft2=ceil(log((double)nn)/log(2.));
     nft = 1; j = 0; while (j++<nft2) nft *= 2;
     if ( (wndw=coswndw(nn,w))==NULL || (spec=(complex *) malloc(nft*sizeof(float)))==NULL) {
        fprintf(stderr,"couldn't alloc array\n");
	free(data);
        continue;
     }
     nft2=nft/2;
     df = 1./(nft*dt);
     fniq = 0.5/dt;
     if (fmax<0. || fmax>fniq) fmax=fniq;
     fprintf(stderr,"nft=%d df=%8.2e Hz fmax=%f Hz\n",nft,df,fmax);
     rtrend(data,nn);
     for(j=0;j<nn;j++) data[j] *= wndw[j];
     for(j=0;j<nft2;j++) spec[j]=Zero;
     memcpy(spec, data, nn*sizeof(float));
     fftr(spec, nft2, dt);

     strcpy(fnm,argv[i]);
     hd.b = 0.;
     hd.e = fmax;
     hd.delta = df;
     hd.npts = rintf(fmax/df);
     data[0] = fabs(spec[0].x);
     for(j=1;j<hd.npts;j++) data[j] = ccabs(spec[j]);
     write_sac(strcat(fnm,".am"),hd,data);
     free(data);
     free(spec);
     free(wndw);
  }

  return 0;
}
