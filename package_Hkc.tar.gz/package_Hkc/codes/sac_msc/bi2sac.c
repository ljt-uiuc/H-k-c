/********************************************************
*	read 1-column binary data from stdin and write them as
*	evenly spaced SAC data.
*	usage:
*		bi2sac delta_t t0
*********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "sac.h"

int main(int argc, char **argv) {
  int i,n,block=512;
  float *aa,dt,t0;
  SACHEAD hd;

  if (argc != 2) {
     fprintf(stderr,"Usage: %s dt[/t0] < binary_file > output\n", argv[0]);
     return 1;
  }

  i = sscanf(argv[1],"%f/%f",&dt, &t0);
  if (i<2) t0 = 0.;

  n = block;
  if ( (aa = (float *) calloc(n,sizeof(float))) == NULL ) return 1;
  i = 0;
  while (fread(aa+i, sizeof(float), 1,stdin)==1) {
    i++;
    if (i==n) {
       n += block; 
       if ( (aa = realloc(aa, n*sizeof(float))) == NULL ) return 1;
    }
  }

  hd = sachdr(dt,i,t0);
  fwrite(&hd, sizeof(SACHEAD), 1, stdout);
  fwrite(aa, sizeof(float), i, stdout);
  fprintf(stderr, "%s finished successfully!\n", argv[0]);
  return 0;

}
