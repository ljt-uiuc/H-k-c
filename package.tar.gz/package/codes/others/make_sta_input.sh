awk '{print $1,"25 101 45.0 55.0 72",$7,$9,"0 360 0 180 0"}' hk_lupei.dat > 0_HA1/sta_input
awk '{print $1,"25 101 45.0 55.0 72",$7,$9,"0 360 0 180 1"}' hk_lupei.dat > 0_HA2/sta_input
awk '{print $1,"25 101 45.0 55.0 72",$7,$9,"0 360 0 180 2"}' hk_lupei.dat > 0_HA3/sta_input
cp codes/files_HA/* 0_HA1
cp codes/files_HA/* 0_HA2
cp codes/files_HA/* 0_HA3
