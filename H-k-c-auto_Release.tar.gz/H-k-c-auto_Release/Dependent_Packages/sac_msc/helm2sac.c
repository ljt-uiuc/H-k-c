/************************************************************
*	Convert Helmberger formated ASCII data to SAC format
*	Usage:
*		helm2sac helm_data_files ...
*************************************************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "sac.h"

int main(int argc, char **argv) {
  int	ic,i,j,n,np;
  float	t0,dt,*a,dist;
  char	aaa[80],cc[3]={'.','0','\0'};
  FILE	*pt;
  SACHEAD hd = sac_null;

  if (argc < 2) {
     fprintf(stderr,"Usage: helm2sac helm_data_files ...\n");
     return 1;
  }

  hd.iftype = ITIME;
  hd.iztype = IO;
  hd.leven = TRUE;
  hd.o=0.;
  for(i=1;i<argc;i++){

     if ((pt=fopen(argv[i],"r")) == NULL) {
	fprintf(stderr, "unable to open %s\n", argv[i]);
	continue;
     }

     fgets(aaa,80,pt);sscanf(aaa,"%d",&np);
     fgets(aaa,80,pt);
     for(ic=0;ic<np;ic++){
	cc[1]=ic+48;
        fgets(aaa,80,pt);sscanf(aaa,"%f %f",&dist,&t0);
        fgets(aaa,80,pt);sscanf(aaa,"%d %f",&n,&dt);
	hd.npts=n;
	hd.b=t0;
	hd.dist=dist;
	hd.delta=dt;
	hd.e=hd.b+hd.npts*hd.delta;
	a=(float *) calloc(n, sizeof(float));
        for(j=0;j<n;j++) fscanf(pt,"%f",a+j);
        strcpy(aaa,argv[i]);
	if (write_sac(strcat(aaa,cc), hd, a) < 0) {
	   return -1;
	}
	free(a);
	fgets(aaa,80,pt);
     }
     fclose(pt);
  }

  return 0;

}
