/************************************************************
* fit instrument calibration sac trace with theoretical response
* to estimate free freq., damping, and gain.
*    ref. Rodgers et al., BSSA, 85, 845-850, 1995
************************************************************/
#include<stdio.h>
#include<math.h>
#include<string.h>
#include "sac.h"
#include "Complex.h"
#include "inversion.h"

int main(int argc, char **argv) {
    int i,k,ix,iy,nx,ny,n,delay,t0,error=0;
    char fname[512];
    float x,xmin,dx,sx,y,ymax,dy,sy,sxy,dt,amp,dc,*c,*u,*data;
    void rp(float *,float,int,float,float);
    SACHEAD hd;

    /* input parameters */
    n = 0;
    nx = 0;
    ny = 0;
    for (i=1; !error && i < argc; i++) {
      if (argv[i][0] == '-') {
         switch(argv[i][1]) {
         case 'R':
           sscanf(&argv[i][2],"%f/%f/%f/%f/%f/%f",&xmin,&sx,&dx,&sy,&ymax,&dy);
	   nx = rint((sx-xmin)/dx)+1;
	   ny = rint((ymax-sy)/dy)+1;
           break;
         case 'T':
           sscanf(&argv[i][2],"%d",&n);
	   break;
         default:
	   error = 1;
         }
      }
    }
    if (argc < 3 || error || n<1 || nx<1 || ny<1) {
       fprintf(stderr,"Fit sac CAL traces to get free period, damping, and gain\n\
        usage: %s -Rf1/f2/df/h1/h2/dh -Tn sacfiles ...\n\
        Output: f h gain delay dc cor\n",argv[0]);
       return -1;
    }

    c = (float *) malloc(nx*ny*sizeof(float));
    u = (float *) malloc(n*sizeof(float));

    for(i=1;i<argc;i++) {

       if (argv[i][0] == '-') continue;
       /* input data */
       fprintf(stderr,"%s\n",argv[i]);
       if ( (data = read_sac(argv[i],&hd)) == NULL) continue;
       dt = hd.delta;
       t0 = rint((hd.a-hd.b)/dt);
       if (t0<0 || hd.npts-(n+t0)<0) {
	  fprintf(stderr,"%   missed the begining or end, skip...\n");
          continue;
       }
       dc = 0.;
       for(ix=0;ix<t0;ix++) dc+=data[ix];
       for(ix=t0+n;ix<hd.npts;ix++) dc+=data[ix];
       dc=dc/(hd.npts-n);
       for(ix=0;ix<n;ix++) data[t0+ix] -= dc;

       /* grid search */
       for (k=0,iy=0;iy<ny;iy++) {
          y = ymax - iy*dy;
          for(ix=0;ix<nx;ix++,k++) {
   	     x = xmin + ix*dx;
   	     rp(u,dt,n,x,y);
   	     c[k] = -maxCor(data+t0,u,n,-1,&delay,&amp);
          }
       }
       amp = grid2d(c,nx,ny,&x,&sx,&y,&sy,&sxy,&k,&error);
       x = xmin+x*dx;
       y = ymax-y*dy;
       rp(u,dt,n,x,y);
       c[0] = maxCor(data+t0,u,n,-1,&delay,&amp);

       /* output results */
       fprintf(stdout,"%s %6.3f %6.3f %6.2f %6.3f %8.4f %6.2f\n",argv[i],x,y,amp,(t0+delay)*dt,dc,c[0]);
       for(ix=0;ix<n;ix++) u[ix] = amp*u[ix]+dc;
       hd.npts = n;
       hd.b = (t0+delay)*dt;
       strcpy(fname,argv[i]);
       write_sac(strcat(fname,".mod"),hd,u);
       free(data);
    }
    return 0;
}

/* step-response of a seismometer with natural freq of f0 and damp h*/
void rp(float *u, float dt, int n, float f0, float h) {
  int i;
  float w0,a,t;
  w0 = 2*3.14159265*f0;
  a = w0*sqrt(1.-h*h);
  for(t=0.,i=0;i<n;i++) {
     u[i] = exp(-h*w0*t)*sin(a*t)/a;
     t += dt;
  }
  return;
}
