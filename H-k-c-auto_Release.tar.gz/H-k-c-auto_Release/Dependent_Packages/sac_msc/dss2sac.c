/*
convert Chinese DSS binary data to sac traces
author	Lupei Zhu, 06/01/2002; modified on 6/29/2004
reference: Wang et al., Acta Geophysica Sinica, Vol 34 (4), 455-464, 1991
*/

#include <stdio.h>
#include <math.h>
#include <string.h>
#include "sac.h"

#define NCH 300		/* max. number of traces in a data file */
#define MSP 4096	/* max. number of samples in a trace */

int main(int argc, char **argv) {

  struct dx_head1 {
    char buf1[80];
    short msamp, rate, rec, maxr, itmin;
  } dx1;
  float vred;
  struct dx_head2 {
    short id1,id2;
  } dx2[NCH];
  short idb[NCH], chanl[NCH];
  float rdist[NCH], az[NCH];
  struct dx_head3 {
    short nsp, isp, nsize, iidsp, isite, elev, month, day, hr, min;
    char  sec[4];
    short year;
    short latd;
    char  latm[4];
    short lond;
    char  lonm[4];
    char  pad[28];
  } dx3;
  short buf[MSP];
  float data[MSP];

  int i, j, n;
  char fname[128];
  float sec,latm,lonm;
  SACHEAD hd;
  FILE *ipt;

  if ( (ipt = fopen(argv[1],"rb")) == NULL) {
     fprintf(stderr, "error in opening %s\n",argv[1]);
     return 1;
  }
  if ( fread(&dx1, sizeof(struct dx_head1), 1, ipt) != 1) {
     fprintf(stderr, "error in reading head\n");
     return 1;
  }
  fread(&vred,sizeof(float),1,ipt);
  fprintf(stderr,"vred=%f tmin=%d\n", vred, dx1.itmin);
  n = dx1.rec; if (n<150) n=150;	/* old data header has 150 reserved */
  fread(dx2,  sizeof(struct dx_head2),n,ipt);
  fread(idb,  sizeof(short),n,ipt);
  fread(chanl,sizeof(short),n,ipt);
  fread(rdist,sizeof(float),n,ipt);
  fread(az,   sizeof(float),n,ipt);
  fread(&dx3,sizeof(struct dx_head3),1,ipt);
  sscanf(&dx3.sec[0],"%f",&sec);
  sscanf(&dx3.latm[0],"%f",&latm);
  sscanf(&dx3.lonm[0],"%f",&lonm);
  hd = sachdr(0.001*dx1.rate,dx1.msamp,0.);
  hd.o = 0.;
  hd.nzyear = dx3.year;
  hd.nzjday = dx3.month*30+dx3.day;
  hd.nzhour = dx3.hr;
  hd.nzmin = dx3.min;
  hd.nzsec = sec;
  hd.nzmsec = 1000*(sec-hd.nzsec);
  hd.evla = dx3.latd+latm/60.;
  hd.evlo = dx3.lond+lonm/60.;
  hd.evdp = -0.001*dx3.elev;
  printf("%s %d/%d/%d %d:%d:%05.2f %6.3f %7.3f %4.2f %d %d %d\n", argv[1],
  	dx3.year,dx3.month,dx3.day,dx3.hr,dx3.min,sec,
	hd.evla,hd.evlo,hd.evdp,dx1.rec,dx1.msamp,dx1.rate);
  for(i=0;i<dx1.rec;i++) {
    hd.dist = fabs(rdist[i]);
    hd.az = az[i];
    hd.b = dx1.itmin + hd.dist/vred;
    hd.user0 = dx2[i].id1;
    hd.user1 = dx2[i].id2;
    hd.user2 = idb[i];
    printf("%3d %3d %3d %3d %6.2f %6.2f\n",dx2[i].id1,dx2[i].id2,idb[i],chanl[i],hd.dist,hd.az);
    if (fread(buf, sizeof(short), dx1.msamp, ipt)!=dx1.msamp) {
       fprintf(stderr, "error in reading data\n");
       return 1;
    }
    for(j=0;j<dx1.msamp;j++) data[j] = buf[j];
    sprintf(fname,"%03d",i);
    write_sac(fname,hd,data);
  }
  fclose(ipt);
  return 0;
}
