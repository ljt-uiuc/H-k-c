/***************************************************************
*	Convolve two sac files
*	Usage:
*	 sac_convlv sac_file1 sac_file2 output_file
*	Note file1 should be much shorter than file2, output length
*	is same as file2.
*
*	Revision History
*		Lupei Zhu	08/26/97	Initial coding
***************************************************************/

#include <stdio.h>
#include "sac.h"
#include "Complex.h"

int main(int argc, char **argv) {
  float		*data1, *data2;
  SACHEAD	hd1, hd2;

  if ( argc < 3 ) {
     fprintf(stderr, "Usage: %s sac_file1 sac_file2 [output_file]\n\
  sac_file1 need to be shorter than sac_file2\n",argv[0]);
     return -1;
  }

  if ( (data1 = read_sac(argv[1], &hd1)) == NULL
    || (data2 = read_sac(argv[2], &hd2)) == NULL ) {
    return -1;
  }

  conv(data1, hd1.npts, data2, hd2.npts);

  hd2.b += hd1.b; hd2.e += hd1.b;
  write_sac(argv[argc-1], hd2, data2);

  return 0;

}
