/********************************************************
*	Show SAC data point at specified time
*	Usage:
*		lsac time sac_files ...
********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "sac.h"

int main(int argc, char **argv) {
  SACHEAD	hd;
  int		i, j;
  float		*ar;
  float		scale=1;

  if (argc < 3) {
     fprintf(stderr, "Usage: %s scale sac_files ...\n",argv[0]);
     return -1;
  }

  sscanf(argv[1],"%f",&scale);

  for (i=2;i<argc;i++) {
     fprintf(stderr,"%s\n",argv[i]);
     if ((ar = read_sac(argv[i],&hd)) == NULL) continue;
     for(j=0;j<hd.npts;j++) ar[j] *= scale;
     write_sac(argv[i],hd,ar);
     free(ar);
  }

  return 0;
}
