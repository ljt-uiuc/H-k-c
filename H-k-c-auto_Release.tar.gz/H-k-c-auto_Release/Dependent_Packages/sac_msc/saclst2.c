/************************************************************
*	List the SAC header fields
*	Usage
*		saclst header_variable_names ... f sac_files ...
*	author: Lupei Zhu 1995/3/12 Caltech
*************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "sac.h"

#define NHD 133		/* number of fields in sac header */
#define MAX_CHAR 16	/* max char length of field name */

void	sac_head(char a[NHD][MAX_CHAR]);

int main(int argc, char **argv)
{
  int		i, j, nl, ls[NHD], offset, len;
  char		fields[NHD][MAX_CHAR],temp[32];
  void		*pt;
  SACHEAD	hd;

  if(argc<2) {
      fprintf(stderr,"Usage: saclst header_lists f file_lists\n");
      return -1;
  }

  sac_head(fields);
  /*for(i=0;i<NHD;i++) printf("%d %s\n",i,fields[i]);*/

  nl=0;argv++;argc--;
  while ( argc>0 && *argv[0] != 'f' ) {
     if (strcmp(argv[0],"kztime") == 0) {
	ls[nl] = NHD+1;
     } else {
        for(i=0;i<NHD;i++) {
	   if (strcmp(argv[0],fields[i]) == 0) break;
        }
        ls[nl] = i;
        if (ls[nl]==NHD) {
	   fprintf(stderr, "error in header_list  %s\n",argv[0]);
	   return -1;
        }
     }
     nl++; argv++; argc--;
  }

  for (i=1;i<argc;i++) {

      printf("%s",argv[i]);

      if ( read_sachead(argv[i], &hd) != -1) {
	pt = &hd;
        for (j=0;j<nl;j++) {
	  if (ls[j] == NHD+1) {
	     printf(" %4d %3d %2d %2d %6.3f",hd.nzyear,hd.nzjday,hd.nzhour,hd.nzmin,hd.nzsec+0.001*hd.nzmsec);
	  } else if (ls[j]<70) {
	     printf(" %e", *((float *) pt + ls[j]));
	  } else if (ls[j]<110) {
	     printf(" %d", *((int *) pt + ls[j]));
	  } else {
	     offset = 440 + 8*(ls[j]-110);
	     len = 8;
	     if (ls[j] == 112) len=16;
	     if (ls[j]>112) offset += 8;
	     strncpy(temp, (char *) pt + offset, len);
	     printf(" %s", temp);
	  }
        }
      }

      printf("\n");

  }
  return 0;

}


void	sac_head(char fields[NHD][MAX_CHAR]) {
  int  i;
  char line[128],type[16];
  FILE *fn;
  fn = fopen("/auto/terra-01/lupei/Src/sac_msc/sac.h","r");
  if (fn == NULL) {
     fprintf(stderr,"couldn't find sac header file\n");
     exit(0);
  }
  i = -1000;
  while (fgets(line,128,fn) && i<NHD) {
     i++;
     if (line[0] == '{') i = -1;
     if (i>=0) sscanf(line,"%s %[0-9a-z]",type,fields[i]);
  }
  fclose(fn);
}
