#!/bin/bash

# Shell script for gathering Hkc results
# Created by Junyi Gong, 2022/09/04

ProjectName=$1

rm -rf ${ProjectName}_Run*
rm -f ${ProjectName}_StaInfo
rm -f slurm-*_*.out
rm -f run_JobAutoSubmit.sbatch
rm -f run_Summarize.sbatch
