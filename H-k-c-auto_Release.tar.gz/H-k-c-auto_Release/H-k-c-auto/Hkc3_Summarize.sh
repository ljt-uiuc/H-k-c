#!/bin/bash

# Shell script for gathering Hkc results
# Created by Junyi Gong, 2022/09/04

ProjectName=$1
RunStart=$2
RunEnd=$3
station_nums=$4

currentdir=`pwd`


rm -rf ${currentdir}/${ProjectName}_Results
mkdir ${ProjectName}_Results

for i in `seq ${RunStart} ${RunEnd}`
do
{
  onerun="${ProjectName}_Run${i}"
  cd ${onerun}

  for dir in run${i}_0_HA1 run${i}_0_HA2 run${i}_0_HA3 run${i}_allbefore run${i}_allafter run${i}_hk_before run${i}_hk_after
  do
    cd ${dir}
    
    for sta in `seq 1 ${station_nums}`
    do
     gs -dSAFER -dBATCH -dNOPAUSE -r200 -sDEVICE=png16m -dTextAlphaBits=4 -dGraphicsAlphaBits=4 -sOutputFile=${sta}.png ${sta}.pdf
    done

    rm -f *.pdf
    cd ..
  done

  for dir in run${i}_HA1_results run${i}_HA2_results run${i}_HA3_results run${i}_allHA_results run${i}_test_tt_results run${i}_test_tt2hk_results 
  do
    cd ${dir}
    filename="${dir}.dat"
      for sta in `seq 1 ${station_nums}`
      do
        cat ${sta}.dat >> ${filename}
      done
    mv ${filename} ..
    cd ..
    rm -rf ${currentdir}/${onerun}/${dir}
  done

  for dir in run${i}_hk_before_results run${i}_hk_std_before_results run${i}_hk_after_results run${i}_hk_std_after_results 
  do
    cd ${dir}
    filename="${dir}.out"
      for sta in `seq 1 ${station_nums}`
      do
        cat ${sta}.out >> ${filename}
      done
    mv ${filename} ..
    cd ..
    rm -rf ${currentdir}/${onerun}/${dir}
  done


  cd ${currentdir}
  mv ${onerun} ${ProjectName}_Results 
}&
done

wait

mv ${ProjectName}_Raw.txt ${ProjectName}_Results 
mv baz_absense.dat ${ProjectName}_Results

tar cvf ${ProjectName}_Results.tar ${ProjectName}_Results
mv ${ProjectName}_Results.tar .. 

