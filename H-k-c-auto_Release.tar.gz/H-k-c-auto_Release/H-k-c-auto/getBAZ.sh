#!/bin/bash

# Shell script for getting maximal baz coverage absence for given RF dataset
# Junyi Gong 2022/09/17

matchpattern=$1

cd RFDATA
rm -f baz_absense.dat

for dir in `ls -d */`
do

#If Endianness conflicts, saclst command fails.
#following command will get rid of this trouble
sac << EOF
r ${dir}/${matchpattern}
w over
q
EOF


saclst baz f `ls ${dir}/${matchpattern}` | sort -n -k 2 -o  baztemp

baz_list=(`awk '{print $2}' baztemp | tr -s "\n" " "`)
totaline=(`awk 'END{print NR}' baztemp`)

  for n in `seq 0 $((${totaline}-1))`
  do
    if [ ${n} == $((${totaline}-1)) ]
    then
      baz_absense[${n}]=`echo "scale=2; 360-${baz_list[${n}]}+${baz_list[0]}" | bc`
    else
      baz_absense[${n}]=`echo "scale=2; ${baz_list[$((${n}+1))]}-${baz_list[${n}]}" | bc`
    fi
  done

  maxval=0
  for n in `seq 0 $((${totaline}-1))`
  do
    k=${baz_absense[${n}]}
    if [ `echo "${k} > ${maxval}" | bc` -eq 1 ]
    then
      maxval=${k}
    fi 
  done

  echo ${dir} ${maxval} >> baz_absense.dat

unset baz_list
unset baz_absense
unset maxval

echo "${dir} done!"

done
rm baztemp
mv baz_absense.dat ..
cd ..
