#!/bin/bash

# A shell script that helps to list all stations from sac files.
# It can also rearrange sac files by station, rather than by event.
#
# Junyi Gong, 2022/06/27

CurrentDir=`pwd`
DataDir='RFs'
NewDir='SETibet_Data'
StaInfo_File='SETibet.loc'


mkdir Check
mkdir ${NewDir}
NewDir_path=${CurrentDir}/${NewDir}
rm -f ${StaInfo_File}

echo ${NewDir_path}

cd ${DataDir}

for dir in `ls -d */`
do
cd ${dir}
echo ${dir}

dir_now=`pwd`

for file in `ls *.eqr`
do

# get Station Name, Lon, Lat and Elevation
sac>temp.txt  << EOF
r ${file} 
lh kstnm stlo stla stel 
quit
EOF

stnm0=`cat ./temp.txt | grep 'kstnm'`
stlo0=`cat ./temp.txt | grep 'stlo'`
stla0=`cat ./temp.txt | grep 'stla'`
stel0=`cat ./temp.txt | grep 'stel'`

stnm=${stnm0#*=}
stlo=${stlo0#*=}
stla=${stla0#*=}
stel=${stel0#*=}

#echo ${stnm}
#echo ${stlo}
#echo ${stla}
#echo ${stel}

cd ${NewDir_path}

if [ -d ${stnm} ];then
# station directory already exists
count=`ls -l ${stnm} |grep "^-"|wc -l`
((count++))
cd ${stnm}
dir_temp=`pwd`

cd ${dir_now}
cp ${file} ${dir_temp}
cd ${dir_temp}

mv ${file} ${count}_${file}
printf "%s, %f, %f, %f\n" ${stnm} ${stlo} ${stla} ${stel} >> ${CurrentDir}/Check/${stnm}.check

else
# station directory doesn't exist
mkdir ${stnm}
cd ${stnm}
dir_temp=`pwd`

cd ${dir_now}
cp ${file} ${dir_temp}
cd ${dir_temp}
mv ${file} 1_${file}

printf "%s %f %f %f\n" ${stnm} ${stlo} ${stla} ${stel}  >> ${CurrentDir}/Check/${stnm}.check
printf "%s %f %f %f\n" ${stnm} ${stlo} ${stla} ${stel}  >> ${CurrentDir}/${StaInfo_File}
fi

cd ${dir_now}

done

rm -f temp.txt
cd ..

done

cd ..
