# !/bin/bash

Input=$1

awk -F ',' -v p=' ' '{print $1p$2p$3p$4}' ${Input} > New.txt

mv ${Input} ${Input}_bak
rm -f ${Input}

cat New.txt > ${Input}

rm -f New.txt
