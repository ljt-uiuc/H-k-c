#!/bin/bash
#
# A shell script to exact staion information from SANDWICH-like data
# SANDWICH data: gathered by station, but with no station information description file
# Junyi Gong, 2022/06/28


DataDir='Tibet_RF_matitdec'
StaInfo_File='SANDWICH.loc'

rm -f ${StaInfo_File}
cd ${DataDir}

for dir in `ls -d */`
do

# Exact one sac file
temp=`ls ${dir} | awk 'NR==1{print}'`
file=./${dir}/${temp}

# get Station Name, Lon, Lat and Elevation
sac>temp.txt  << EOF
r ${file} 
lh kstnm stlo stla stel 
quit
EOF

stnm0=`cat ./temp.txt | grep 'kstnm'`
stlo0=`cat ./temp.txt | grep 'stlo'`
stla0=`cat ./temp.txt | grep 'stla'`
stel0=`cat ./temp.txt | grep 'stel'`

stnm=${stnm0#*=}
stlo=${stlo0#*=}
stla=${stla0#*=}
stel=${stel0#*=}

printf "%s %f %f %f\n" ${stnm} ${stlo} ${stla} ${stel}  >> ${StaInfo_File}

# rename every dir
echo ${dir} ${stnm}
mv ${dir} ${stnm}

done

mv ${StaInfo_File} ..
