#!/bin/bash

matchpattern='*.sac'

for m in `ls RFDATA/*/${matchpattern}`
do

sac << EOF
cut -5 100
cuterr fillz
r ${m}
w over
q
EOF

echo "${m} done!"

done
