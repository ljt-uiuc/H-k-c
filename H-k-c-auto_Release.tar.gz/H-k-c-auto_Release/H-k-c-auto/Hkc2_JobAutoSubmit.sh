#!/bin/bash

# Shell script for automatically submitting jobs to HPC
# Created by Junyi Gong 2022/09/03

ProjectName=$1
RunStart=$2
RunEnd=$3
current_task=$4
datadir='RFDATA'
Hkc_package0='package_Hkc'

currentdir=`pwd`
Runs=$((${RunEnd}-${RunStart}+1))

# Get current station number and current input plan number
# j: current station number
# i: current input plan number
idx=$((${current_task}%${Runs}))
if [ ${idx} -eq 0 ]; then
  idx=${Runs}
fi
j=$(((${current_task}-${idx})/${Runs}+1))
i=$((${idx}-1+${RunStart}))

# Prepare Hkc package and Data
onerun="${ProjectName}_Run${i}"
input_file="${ProjectName}_Run${i}.dat"

Hkc_package=${Hkc_package0}_${j}

cp -r ${currentdir}/${Hkc_package0} ${currentdir}/${onerun}/${Hkc_package}

sed -n ${j}p ${currentdir}/${onerun}/${input_file} > ${currentdir}/${onerun}/${Hkc_package}/hk_lupei.dat
stnm=`sed -n ${j}p ${currentdir}/${onerun}/${input_file} | awk '{print $1}'`
echo ${stnm} > ${currentdir}/${onerun}/${Hkc_package}/sta.txt

cp -r ${currentdir}/${datadir}/${stnm} ${currentdir}/${onerun}/${Hkc_package} 

# Run Hkc
cd ${currentdir}/${onerun}/${Hkc_package} 
csh run1_prep.csh
csh run2_HA.csh
csh run3_Hkc.csh

# Summarize Results
cd ${currentdir}

# Harmonic Analysis Results
# for Ps
cp ${currentdir}/${onerun}/${Hkc_package}/0_HA1/0_HA1.pdf ${currentdir}/${onerun}/run${i}_0_HA1/${j}.pdf 
cat ${currentdir}/${onerun}/${Hkc_package}/0_HA1/*max_ani_dip_tref_error.dat > ${currentdir}/${onerun}/run${i}_HA1_results/${j}.dat
# for M1
cp ${currentdir}/${onerun}/${Hkc_package}/0_HA2/0_HA2.pdf ${currentdir}/${onerun}/run${i}_0_HA2/${j}.pdf
cat ${currentdir}/${onerun}/${Hkc_package}/0_HA2/*max_ani_dip_tref_error.dat > ${currentdir}/${onerun}/run${i}_HA2_results/${j}.dat
# for M2
cp ${currentdir}/${onerun}/${Hkc_package}/0_HA3/0_HA3.pdf ${currentdir}/${onerun}/run${i}_0_HA3/${j}.pdf 
cat ${currentdir}/${onerun}/${Hkc_package}/0_HA3/*max_ani_dip_tref_error.dat > ${currentdir}/${onerun}/run${i}_HA3_results/${j}.dat

# H-kappa Results
cp ${currentdir}/${onerun}/${Hkc_package}/0_H-k/allbefore.pdf ${currentdir}/${onerun}/run${i}_allbefore/${j}.pdf
cp ${currentdir}/${onerun}/${Hkc_package}/0_H-k/allafter.pdf ${currentdir}/${onerun}/run${i}_allafter/${j}.pdf
# for Hk before
cp ${currentdir}/${onerun}/${Hkc_package}/0_H-k/all_before/hk_before.pdf ${currentdir}/${onerun}/run${i}_hk_before/${j}.pdf
cat ${currentdir}/${onerun}/${Hkc_package}/0_H-k/all_before/hk_before.out > ${currentdir}/${onerun}/run${i}_hk_before_results/${j}.out
cat ${currentdir}/${onerun}/${Hkc_package}/0_H-k/all_before/std_before.out > ${currentdir}/${onerun}/run${i}_hk_std_before_results/${j}.out
# for Hk after
cp ${currentdir}/${onerun}/${Hkc_package}/0_H-k/all_after/hk_after.pdf ${currentdir}/${onerun}/run${i}_hk_after/${j}.pdf
cat ${currentdir}/${onerun}/${Hkc_package}/0_H-k/all_after/hk_after.out > ${currentdir}/${onerun}/run${i}_hk_after_results/${j}.out
cat ${currentdir}/${onerun}/${Hkc_package}/0_H-k/all_after/std_after.out > ${currentdir}/${onerun}/run${i}_hk_std_after_results/${j}.out

# Other Results
cat ${currentdir}/${onerun}/${Hkc_package}/0_H-k/test_result.dat > ${currentdir}/${onerun}/run${i}_allHA_results/${j}.dat
cat ${currentdir}/${onerun}/${Hkc_package}/test_tt.dat > ${currentdir}/${onerun}/run${i}_test_tt_results/${j}.dat
cat ${currentdir}/${onerun}/${Hkc_package}/test_hk.dat > ${currentdir}/${onerun}/run${i}_test_tt2hk_results/${j}.dat

# Release storage
cd ${currentdir}/${onerun}
rm -rf ${Hkc_package}

cd ${currentdir}
