H-k-c package

Generalized H-k after harmonic correction on receiver functions

a modification of H-k method by Zhu and Kanamori (2000)

by Jiangtao Li, Xiaodong Song, Pan Wang, and Lupei Zhu

Reference: Li, J., Song, X., Wang, P., & Zhu, L. (2019). A generalized H-k method with harmonic corrections on Ps and its crustal multiples in receiver functions. J. Geophys. Res. Solid Earth, 124(4), 3782-3801.

Contact: jiangtaoli@whu.edu.cn; xdsong@pku.edu.cn
