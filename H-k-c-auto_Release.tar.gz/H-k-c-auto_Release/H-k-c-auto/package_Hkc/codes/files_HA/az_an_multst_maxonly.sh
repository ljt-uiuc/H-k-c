#!/bin/bash
# all right reserved, Pan Wang, 2014 June 22
# a few modifications by Jiangtao Li, 2018
# station data analysis based on back-azimuthal bins
# platform Moho, dipping Moho, and anisotropic crust

mkdir output_pdf
rm 1 *dat *if *ani demo* *grd -f
dt='0.025'  # edit here sample ratio 1/$dt  
dptrg='0.5' # edit here the range of A1 for searching
anstrg='0.5' # edit here the range of A2 for searching
shftrg='1.25' # edit here the range of the m for searching ( from -m to m ), m is the remaining between t_REF and t_MC

gmtset PAPER_MEDIA a3
gmtset PAGE_ORIENTATION portrait
echo "------------------------------------------"
echo platform Moho, dipping Moho, and anisotropic crust
echo "for synthetic data dt = " $dt
echo "------------------------------------------"

echo "input the file name of the baz coverage result"
#read stlist

stlist='sta_input' # edit here the file of the station list for computing, the format refer to the example

dos2unix $stlist
echo "input the process mark"
#read trk
trk="demo_" # edit here the marker for different tryings
rm -f ${trk}_rst_list.dat

#stlist='baz_cov.dat'
if [ -s $stlist ]; then 
ni='1'
while [ 2 > 1 ]
do
sed -n " $ni p " $stlist > ${trk}_prmt_in
if [ ! -s ${trk}_prmt_in ] ; then
echo job done
exit 
fi
 
read stnm stla stlo bazc1 bazc2 ev_totle refh refk theta1b theta1e theta2b theta2e case < ${trk}_prmt_in
ni=` expr $ni + 1 `

#for each stion

echo "------------------------------------------"
echo 'analyzing st:' $stnm ' Records: ' $ev_totle
echo 'at  LAT' $stla 'LONG' $stlo
echo 'Whole Circle coverage : ' $bazc1
echo ' half Circle coverage : ' $bazc2
echo "------------------------------------------"

if [ `echo $bazc2 " >= 50 " | bc ` = 1 ] ; then  # edit here the number 50 is the percent BAZ coverage in 0 - 180. the BAZ over 180 should be projected to BAZ - 180. 
	echo 'analyzing'
else
	echo 'bad data coverage'
	continue
fi

# do not edit any between the two EOFs
# the 4 numbers "1 0 0 1" control the models for computing

./az_an_singlest_model << EOF
$dt
$dptrg
$anstrg
$shftrg
$stnm
$stla
$stlo 
$bazc1
$bazc2
$ev_totle
$refh
$refk
$case
$trk
1
0
0
1
$theta1b
$theta1e
$theta2b
$theta2e
EOF

ps='./output_pdf/'$stnm'_HA.ps'  #edit here to modify path and name of the output plots
# do not change any in following lines. 

#ps='test.ps'
dos2unix ${trk}mc.dat

read stnm2 mc1 mohod pf1 avvp hck kapa  stla stlo bac1 bac2 evtlt < ${trk}mc.dat

ps_tb=`echo "  $mc1 / 1 - 2" | bc `
ps_te=`echo "  $mc1 / 1 + 3" | bc `

	echo "------------------------------------------"
	echo 'Moho depth: ' $mohod " km"
	echo 'moveout correction: ' $mc1 'sec'
	echo "------------------------------------------"

cat ${trk}mc.dat >>  ${trk}rst_mc.dat

gmtset ANOT_OFFSET 0.1c
gmtset LABEL_OFFSET 0.05c
gmtset HEADER_OFFSET 0.1c
gmtset HEADER_FONT_SIZE 28
gmtset LABEL_FONT_SIZE 28
gmtset ANOT_FONT_SIZE 24

#---------------------------------
#anisotropy associat with dipping curv display 
psbasemap -K -R$ps_tb/$ps_te/-5/360 -P  -JX7/15 -Y26 -X4 -Ba1f0.5:"Time (s)":/a30f10:"BAZ (\\260)":WeSn > $ps
i=1
k=0
#k2=0
while read i rst # [ $i -lt 73 ]
do

k=`echo "scale=2 ; $i * 5 - 5" | bc `


if [ $case = 3 ] ; then
gawk -v t=$dt -v i=$i -v k=$k '{print -10+NR*t,k,-$i }' ${trk}baz_wav_st.dat | pswiggle  -O -K -R -J -Wthin -Gblue -N -Z0.5  >> $ps
else
gawk -v t=$dt -v i=$i -v k=$k '{print -10+NR*t,k,$i }' ${trk}baz_wav_st.dat | pswiggle  -O -K -R -J -Wthin -Gred -Z0.5  >> $ps
fi

#gawk ' {print -10+NR*0.025,'$k2',$'$i' }' ${trk}baz_wavt_st.dat | pswiggle -O -K -R  -J  -Wthin -Gblue -Z1  >> $ps

done <  ${trk}baz_cov_st.dat


#gawk '{print $2,"0\n",$2,"370"}' ${trk}mc.dat | psxy -O -K -R -J -Wthicker,red >>$ps
#gawk '{print $4,"0\n",$4,"370"}' ${trk}mc.dat | psxy -O -K -R -J -Wthicker,black >>$ps
gawk '{if(NR <= 72) print $2,$1}' ${trk}_da_cur.dat | psxy -O -K -M -R -J -Wthickest,black >>$ps 
#gawk '$1 == ">" {print $3,$2,"24 0 5 CT ",$4}' ${trk}_ans_cur.dat | pstext -O -Dj0/-0.5v -K -R -J -Gblack >>$ps


### Ploting A1 vs. A2
rm _3.grd
awk '{print $1/2,$2/2,$3}' ${trk}a1a2.dat | surface -G_3.grd -R0/$dptrg/0/$anstrg -I0.01/0.01
psbasemap  -O -K -Y-11 -R0/$dptrg/0/$anstrg -JX7/7 -Ba0.2f0.1:"A@-1@- (s)":/a0.2f0.1:"A@-2@- (s)"::."A@-1@-/A@-2@- energy map":WeSn >>$ps
grdimage _3.grd -O -K -Cenergy_map.cpt -Bwens -R -J >>$ps
grdcontour _3.grd -O -K -C0.01 -L0.985/0.99 -R -J -Wthin,white >> $ps
gawk '{if(NR==1) print $2/2,$4/2 }' ${trk}_da_if |psxy -O -K -M -R -J -S+0.5 -W2p,white >>$ps
#psscale -O -K -D5/-2.3/10/0.4/h -Cenergy_map2.cpt -Ba0.2 >> $ps


#anisotropy associat dipping testing
#max1=`gawk 'NR==1 {print $5}' ${trk}_da_if`
#div=`echo "scale=7 ; $max1 / 25 " | bc`
#max=`echo "scale=7 ; $max1 + $div " | bc`
##makecpt -Chot -I -T0/$max/$div  > ${trk}rainborn.cpt
rm _1.grd
###surface  ${trk}nda2.dat -G_1.grd -R0/180/0/$anstrg -I1/0.01
awk '{print $1,$2/2,$3}' ${trk}nda2.dat | surface -G_1.grd -R0/180/0/$anstrg -I1/0.01
#makecpt -Cjet -N -S0.6/1/0.005 -Z  > energy_map.cpt
###psbasemap -O -K -X12 -R-5/185/0/$anstrg -JX10/5.5 -Ba45f15:"FVD (\\260)":/a0.2f0.05:"@:28:@~t@~@-A@-@:: sec"::,s::."D)Energy map view in anisotropy projection":WeSn >>$ps
psbasemap -O -K -X10 -R0/180/0/$anstrg -JX9/7 -Ba45f15:"@~q@~@-2@- (\\260)":/a0.2f0.1:"A@-2@- (s)"::."cos2@~q@~ energy map":WeSn >>$ps
grdimage _1.grd  -O -K -Cenergy_map.cpt -R -Bwens -J >>$ps
grdcontour _1.grd -O -K -C0.01 -L0.985/0.99 -R -J -Wthin,white >> $ps
#pscontour  ${trk}nda2.dat -I -O -K -X12 -R-5/185/0/1.5 -C${trk}rainborn.cpt -JX10/5.5 -Ba45f15:"Fast wave direction":/a0.2f0.05:"Delay time"::,s::."d)Anisotropy projection":WeSn >>$ps
gawk '{if(NR==1) print $3,$4/2 }' ${trk}_da_if |psxy -O -K -M -R -J -S+0.5 -W2p,white >>$ps
#gawk '{print $3,$4,"13 0 5 CT ","P"NR }' ${trk}_da_if |pstext -O -K -R -J -Gwhite -Dj0.3/0.3v >>$ps

#echo "T  " $stnm > ${trk}_legend
#gawk '{print "T P"NR" dip "$1" deg","dt "$2"s","fast "$3"deg","dt "$4"sec","AMP"$5, "\nG 1 "  }' ${trk}_da_if >> ${trk}_legend

#pslegend -R -J -O -K -F ${trk}_legend -Dx8/-7.5/15/5/BC >> $ps
#psscale -O -K -D10.5/3/6/0.5 -Cenergy_map2.cpt -Ba0.2 >>$ps


#anisotropy associat dipping testing
rm _2.grd
###surface ${trk}nda.dat -G_2.grd -R0/360/0/$dptrg -I1/0.01
awk '{print $1,$2/2,$3}' ${trk}nda.dat | surface -G_2.grd -R0/360/0/$dptrg -I1/0.01
##psbasemap  -O -K -Y9.5  -R-5/365/0/$dptrg -JX10/5.5 -Ba90f15:"Dipping direction (\\260)":/a0.2f0.05:"@:28:@~t@~@-D@-@:: sec"::,s::."B)Energy map view in dipping projection":WeSn >>$ps
psbasemap  -O -K -Y13 -R0/360/0/$dptrg -JX9/7 -Ba90f30:"@~q@~@-1@- (\\260)":/a0.2f0.1:"A@-1@- (s)"::."cos@~q@~ energy map":WeSn >>$ps
grdimage _2.grd -O -K -Cenergy_map.cpt -Bwens -R -J >>$ps
grdcontour _2.grd -O -K -C0.01 -L0.985/0.99 -R -J -Wthin,white >> $ps
#pscontour  ${trk}nda.dat -I -O -K -Y9.5  -R-5/365/0/1 -C${trk}rainborn.cpt -JX10/5.5 -Ba90f15:"Dipping direction":/a0.2f0.05:"Delay time"::,s::."c)Dipping Projection":WeSn >>$ps
gawk '{if(NR==1) print $1,$2/2 }' ${trk}_da_if |psxy -O -K -M -R -J -S+0.5 -W2p,white >>$ps
#gawk '{print $1,$2,"13 0 5 CT ","P"NR }' ${trk}_da_if |pstext -O -K -R -J -Gwhite -Dj0.3/0.3v >>$ps
psscale -O -K -D4.5/-2.7/9/0.5/h -Cenergy_map.cpt -Ba0.2 >> $ps

read ad td aa ta <<< `gawk '{if(NR==1) printf( "%5.0f %5.2f %5.0f %5.2f \n",  $1, $2/2, $3, $4/2) }' ${trk}_da_if `

echo "T  " $stnm > ${trk}_legend
gawk '{print "T P"NR" dip "$1" deg","dt "$2"s","fast "$3"deg","dt "$4"sec","AMP"$5, "\nG 1 "  }' ${trk}_da_if >> ${trk}_legend

# stacking according to baz
#psbasemap -R-1/15/-5/365  -JX7/9 -Y9.5  -Ba4f2:Time::,s:/a45f15:"BAZ (\\260)"::."B)Binned RF and BAZ coverage":WeSn -K -O >> $ps

#while read i rst #[ $i -lt 73 ]
#do 

## basic waveform
#k=`echo "scale=2 ; $i * 5 " | bc `

#gawk -v t=$dt -v i=$i -v k=$k '{print -10+NR*t,k,$i }' ${trk}baz_wav_st.dat | pswiggle  -O -K -R -J -Wthin -Gred -Z1.5  >> $ps

#done <  ${trk}baz_cov_st.dat

##flat test curve and the maxmum curve
##ps arrival computed
#gawk '{print $2,"0\n",$2,"370"}' ${trk}mc.dat | psxy -O -K -R -J -Wthick,red >>$ps
##ps arrival of the stacked waveform
#gawk '{print $4,"0\n",$4,"370"}' ${trk}mc.dat | psxy -O -K -R -J -Wthick,black >>$ps

line1=`echo "$dptrg * 1.79" | bc `
line2=`echo "$dptrg * 1.38" | bc `
line3=`echo "$dptrg * 1.58" | bc `

if [ $case = 1 ] ; then
echo "0 "$line1" 30 0 1 BL "$stnm": Ps"| pstext -J -R -O -K -N  >> $ps
elif [ $case = 2 ]; then
echo "0 "$line1" 30 0 1 BL "$stnm": M1"| pstext -J -R -O -K -N  >> $ps
elif [ $case = 3 ]; then
echo "0 "$line1" 30 0 1 BL "$stnm": M2"| pstext -J -R -O -K -N  >> $ps
fi

pstext -J -R -O -K -N << END >> $ps
0 $line2 28 0 1 BL @~q@~@-2@-: $aa\\260
180 $line2 28 0 1 BL A@-2@-: $ta s
0 $line3 28 0 1 BL @~q@~@-1@-: $ad\\260
180 $line3 28 0 1 BL A@-1@-: $td s
END
#echo "0 1.4 26 0 1 BL  @~q@~@-2@-: "$aa"\\260     A@-2@-: "$ta" s" | pstext -J -R -O -K -N  >> $ps
#echo "0 1.6 26 0 1 BL  @~q@~@-1@-: "$ad"\\260     A@-1@-: "$td" s" | pstext -J -R -O -K -N  >> $ps

##data coverage
#gawk '$2 > 0 {print 5 * $1 - 2.5 , $2}' ${trk}baz_cov_st.dat | psxy -: -O -K -X8 -JX2p0.5/9 -R0/40/-5/365 -Sx0.3 -Wthin/red -Ba30g5:"RF Number":/a10g10wnSe >> $ps


#data out 

echo ">#" $stnm $stla $stlo $bazc1 $bazc2 $ev_totle `gawk 'END {print $2,$3,$4}' ${trk}mc.dat ` `gawk 'END { print NR }' ${trk}_pf_if ` >> ${trk}rst_pf.dat
#echo ">#" $stnm $stla $stlo $bazc1 $bazc2 $ev_totle `gawk 'END {print $2,$3,$4}' ${trk}mc.dat` `gawk 'END { print NR }' ${trk}_dp_if ` >> ${trk}rst_dp.dat
#echo ">#" $stnm $stla $stlo $bazc1 $bazc2 $ev_totle `gawk 'END {print $2,$3,$4}' ${trk}mc.dat` `gawk 'END { print NR }' ${trk}_ans_if ` >> ${trk}rst_ans.dat
echo ">#" $stnm $stla $stlo $bazc1 $bazc2 $ev_totle `gawk 'END {print $2,$3,$4}' ${trk}mc.dat` `gawk 'END { print NR }' ${trk}_da_if ` >> ${trk}rst_da.dat

cat ${trk}_pf_if >> ${trk}rst_pf.dat
#cat ${trk}_dp_if >> ${trk}rst_dp.dat
#cat ${trk}_ans_if >> ${trk}rst_ans.dat
cat ${trk}_da_if >>  ${trk}rst_da.dat

#echo $stnm $stla $stlo $bazc1 $bazc2 $ev_totle $mc1 $mohod $pf1 $avvp $hck $kapa  >> ${trk}_rst_list.dat
cat ${trk}mc.dat >> ${trk}_rst_list.dat

cd output_pdf
ps2pdf $stnm'_HA.ps'
rm -f $stnm'_HA.ps'
cd ..
rm *.grd _tmp_smy_ani demo__[dlp]* demo_[abdmnp]* -f
done
fi
