#!/usr/bin/perl
#
# do H-k stacking
# usage hk_stack.pl [options] stations ...
#
# defaults
$h1 = 20;
$h2 = 60;
$k1 = 1.5;
$k2 = 2.0;
$outf = "hk.grd";
$vp = 6.3;
$vp_file = 0;
$weight = " ";

#input options
@opts = ();
foreach (grep(/^-/,@ARGV)) {
   $opt = substr($_,1,1);
   @value = split(/\//,substr($_,2));
   if ($opt eq "R") {
     ($h1, $h2, $k1, $k2) = @value;
     if ($k1 eq $k2) {
        $weight="-W1/0/0";
        $outf="h.sac";
     }
   } elsif ($opt eq "K") {
     $weight="-W0/1/0";
     $outf="k.sac";
     open(AAA,$value[0]) or die "couldn't open $value[0]\n";
     $col = 1; $col = 5 if $value[0] eq "hk.dat";
     while(<AAA>) {
	@aa = split;
	$tps{$aa[0]} = $aa[$col];
     }
     close(AAA);
   } elsif ($opt eq "V") {
     if ( -f $value[0] ) {
	$vp_file = 1;
        open(AAA,$value[0]) or die "couldn't open $value[0]\n";
	while(<AAA>) {
	   @aa = split;
	   $vp{$aa[0]} = $aa[1];
        }
	close(AAA);
     } else {
        $vp = $value[0];
     }
   } elsif ($opt eq "M" || $opt eq "N" || $opt eq "W" || $opt eq "I" || $opt eq "T" || $opt eq "U") {
     @opts = (@opts, $_);
   } else {
     printf STDERR "hk_stack.pl [-Idz/dk -KtpsFile -M -Nn -Rh1/h2/k1/k2 -Tn -Un -Vvp -Ww1/w2/w3] stations ...
	-I: grid spacing (0.5/0.01).
	-K: kappa search only by fixing tps reading from tpsFile.
	-M: add more multiples (off).
	-N: use nth-root stacking (1).
	-R: grid-search range for thickness and kappa (20/60/1.5/2.0).
	-T: smoothing (1 point).
        -U: add auto-cc coefficient between Ps and PpPs and specify the half window length (off).
	-V: crustal P velocity or the file that contains Vp of stations (6.3).
	-W: weighting for the three converted phases (0.6/0.3/0.1).\n";
     exit(0);
   }
}

foreach $sta (grep(!/^-/,@ARGV)) {
   next unless -d $sta;
   print STDERR "station $sta\n";
   if ( $outf eq "k.sac" ) {
     $range = "-R$tps{$sta}/$tps{$sta}/$k1/$k2";
   } else { 
     $range = "-R$h1/$h2/$k1/$k2";
   }
   $vp = $vp{$sta} if exists $vp{$sta};
#  print("k_stack $range @opts $weight -V$vp -G$sta/$outf $sta/pp.*.ri\n");
   system("k_stack $range @opts $weight -V$vp -G$sta/$outf $sta/az.*.ri");
   next unless $outf eq "hk.grd";
   $aa = `grdmin -D $sta/hk.grd`; chop($aa);
   print "$aa $vp\n";
}
