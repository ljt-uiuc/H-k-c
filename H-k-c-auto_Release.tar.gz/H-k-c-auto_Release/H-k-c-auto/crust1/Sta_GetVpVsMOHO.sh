#!/bin/bash

# Shell script for getting reference moho-depth and average vp/vs from CRUST1.0 model
# A subroutine for search5p_crust.sh
# Note for revises: 
#   (1) ray parameter p 
#   (2) input variables from external file
#   (3) method for caculating average velocity
#   (4) inputs from CRUST1.0 model, if different program is used
# Created by Junyi Gong 2022/5/5

# Read Input FileName
# Input File Content: StaName Lon Lat
InputFile=$1
OutputFile=${InputFile}_MOHOkappa

if [ -e ${OutputFile} ]
then
  rm -f ${OutputFile}
fi

echo 'Start to read reference MOHO depth and kappa from CRUST1.0 model'
count=0

while read lines
do
  echo 'processing No.'$((++count))' Station.'

  #Read StaName sLon sLat from file
  #Check: Variables need to be consistent with file content
  staName=`echo ${lines} | awk '{print $1}'`
  sLon=`echo ${lines} | awk '{printf "%.4f", $2}'`
  sLat=`echo ${lines} | awk '{printf "%.4f", $3}'`

#run crust 1.0. 
#Note: when inputing station location for crust1.0, Lat first and then Lon second.
./getCN1point>temp.txt << EOF
${sLat} ${sLon}
q
EOF

  #Read Output of CRUST1.0 model

  #Read surface elevation
  surf=`awk '{if ($1~/topography:/) printf "%.6f", $2}' temp.txt`

  #Read Vp, Vs, and bottom elevation for each layer
  #A average Velocity is calculated from V_ave=L_tot/t_tot
  #L_tot is the total length of ray, from moho to free surface   
  #t_tot=sum(Li/Vi)
  #Vi is the seismic velocity of i-th layer, Li is the ray length in i-th layer
  #So a reference ray parameter, p, is used, and therefore:
  #s^2=eta^2+p^2, with eta_i=cos_i/V_i, p_i=sin_i/Vi

  #Hence, sin_i=p_i·Vi, cos_i=sqrt(1-sin_i^2)
  #Vci=Vi·cos_i, L_i=H/cos_i

  #Reference ray parameter p [s/km]
  p='0.06'

  #Search Starting Line for Vp, Vs, bottom elevation
  idx=`awk '{if ($1~/layers:/ && $2~/vp,vs,rho,bottom/) print FNR}' temp.txt`
  ((idx=idx+1))
  
  #Calculating average Vp,Vs
  #Initialization
  H_tot='0.0'
  Lp_tot='0.0'
  Ls_tot='0.0'
  tp_tot='0.0'
  ts_tot='0.0'
  vpl='0.0'
  vsl='0.0'
  sin_pl='0.0'
  sin_sl='0.0'
  cos_pl='0.0'
  cos_sl='0.0'
  btml='0.0'
  Hl='0.0'
  Lpl='0.0'
  Lsl='0.0'
  H_check='0.0'
  vpa='0.0'
  vsa='0.0'
  kappa='0.0'
  kp_bot='0.0'

  #CRUST1.0 sets 8 layers altogether, so the condition for the end loop is l<=idx+7
  for ((l=idx;l<=idx+7;l++))
  do  
    line_temp=`sed -n ${l}p temp.txt`

    vpl=`echo ${line_temp} | awk '{print $1}'`
    vsl=`echo ${line_temp} | awk '{print $2}'`
    btml=`echo ${line_temp} | awk '{print $4}'`
   
    #H_temp:total depth for processed layers
    H_temp=${H_tot} 
    #H_tot:total depth for processed layers + currently processing layer
    H_tot=`echo "${surf} - ${btml}" | bc`
    #Hl:depth for currently processing layer
    Hl=`echo "${H_tot} - ${H_temp}" | bc`

    ((ly=l-idx+1))
    #precision for CRUST1.0 data: 0.01; therefore set eps=0.009
    eps='0.009'
    if [ `echo "$Hl > $eps" | bc` -eq 1 ];then
       #Layer 1 is water layer. Only P wave exists.
       if [ ${ly} -eq 1 ];then
          vsl=${vpl}
       fi
       
       #calculating t
       sin_pl=`echo "scale=8; ${vpl} * ${p}" | bc`
       sin_sl=`echo "scale=8; ${vsl} * ${p}" | bc`
       cos_pl=`echo "scale=8; sqrt(1.0 - ${sin_pl}^2)" | bc`
       cos_sl=`echo "scale=8; sqrt(1.0 - ${sin_sl}^2)" | bc`
       Lpl=`echo "scale=8; ${Hl} / ${cos_pl}" | bc`
       Lsl=`echo "scale=8; ${Hl} / ${cos_sl}" | bc`
       Lp_tot=`echo "scale=8; ${Lp_tot} + ${Lpl}" | bc`
       Ls_tot=`echo "scale=8; ${Ls_tot} + ${Lsl}" | bc`
       tp_tot=`echo "scale=8; ${tp_tot} + ${Lpl} / ${vpl}" | bc`
       ts_tot=`echo "scale=8; ${ts_tot} + ${Lsl} / ${vsl}" | bc`
       H_check=`echo "scale=8; ${H_check} + ${Hl}" | bc`

    fi
  done

  #check
  if [ `echo "(${H_tot} - ${H_check}) < $eps" | bc` -eq 1 ];then
    vpa=`echo "scale=6; ${Lp_tot} / ${tp_tot}" | bc`
    vsa=`echo "scale=6; ${Ls_tot} / ${ts_tot}" | bc`
    kappa=`echo "scale=6; ${vpa} / ${vsa}" | bc`
    
    #diagnosis
    echo "${H_tot} ${vpa} ${vsa} ${kappa}"
   
  else
    vpa='0.0'
    vsa='0.0'
    kappa='0.0'
  fi
  
  #Output
  kp_bot=`echo "scale=3; ${vpl} / ${vsl}" | bc`
  echo "${staName} ${sLon} ${sLat} ${H_tot} ${kappa} ${vpa} ${vsa} ${vpl} ${vsl} ${kp_bot}">>${OutputFile}

done < ${InputFile}

rm -f temp.txt
