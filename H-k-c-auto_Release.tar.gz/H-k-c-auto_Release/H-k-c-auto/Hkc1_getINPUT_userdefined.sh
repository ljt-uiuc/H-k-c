#!/bin/bash

# Shell script for extract reference H kappa from CRUST1.0

# Subroutine: Sta_GetVpVsMOHO.sh (p=0.06 is assumed in this subroutine)

# Note: Check the content of file ${SortedTempSta} 
# Note: Check DataDir and make sure data exists
# Note: Make sure StaInfo_DescripFile is under the same folder with search5_crust.sh

#Define Inputs
ProjectName=$1
StaInfo_DescripFile=$2
RunStart=$3
RunEnd=$4


#Generate Intermediate Variable Names
InputFileRaw="${ProjectName}_Raw.txt"


#Sort Stations according to latitude
#dos2unix ${StaInfo_DescripFile}
cat ./${StaInfo_DescripFile} | sort -n -t ' ' -k 3 -o ./${InputFileRaw}

#Prepare Necessary Files and then Run Hkc.

for i in `seq ${RunStart} ${RunEnd}`
do

  #Prepare hk_lupe.dat
  #Modify here for other intervals
  scale=`echo "scale=2; 1.0 + (${i} - 3) / 20" | bc`
  echo $scale

  awk -v scl="${scale}" '{printf"%s %.5f %.5f %.1f %.1f %.1f %.5f %.1f %.5f %.1f %.1f\n", $1,$3,$2,0,0,0,$4,0,$5*scl,0,0}' ${InputFileRaw} > ${ProjectName}_Run${i}.dat

done

